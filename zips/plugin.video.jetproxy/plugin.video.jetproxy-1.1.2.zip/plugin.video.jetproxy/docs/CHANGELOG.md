# JetProxy Changelog

All notable changes to `plugin.video.jetproxy`.  
Format loosely follows [Keep a Changelog](https://keepachangelog.com/).

---

## [1.1.1] — 2026-10-12

Fixes the 20-second stall when exiting the player, and reduces log noise.

### Fixed

- **Instant player exit (deterministic)** — three root causes found and fixed:
  - `CCurlFile::Stat` HEAD probe: shared `requests.Session` pool returned a stale TCP connection bypassing the HTTP timeout. HEAD requests now never touch upstream — served instantly from cache or minimal HLS stub.
  - GET-based Stat from `CSaveFileState`: `_is_post_playback_probe()` called `xbmc.Player().isPlaying()` from an HTTP handler thread, which **deadlocks ~20s** when the player is shutting down on another thread. Removed all `isPlaying()` calls from HTTP handler paths — probe detection now uses only data signals (watchdog polling + media activity timestamps).
  - **Stale curl connection reuse**: Kodi's curl kept cached connections to `127.0.0.1:49777`. After `_kill_all_active_connections()` closed the proxy side, curl reused the dead connection for the Stat — request went into a black hole, never reached the handler, timed out at 20s. All proxy responses now send `Connection: close` so curl never caches a connection.
  - Watchdog uses adaptive polling (100ms when media idle, 500ms during playback) + stale playlist cache safety net for requests that slip through the race window.
- **`stall_timeout=0` setting** — setting the slider to 0 (disable) was ignored because `0 or DEFAULT` evaluated to the default. 0 now correctly disables the stall watchdog.
- **Adaptive manifest timeout** — manifest upstream timeout reduced from 12s to 4s with a 6s hard total deadline per request (was effectively 48s via retries). A dead/blackholed portal can no longer hang a request past ~6s.
- **Player-stop detection via watchdog polling** — `xbmc.Monitor` callbacks were unreliable (created on main.py's script thread which exits after `plugin.run()`). The watchdog daemon thread now polls `isPlaying()` every 0.5s for True→False transitions and immediately kills all proxy connections.

### Changed

- **Log noise reduced** — diagnostic INFO logs demoted to DEBUG: playlist dumps, `local stream_url`, `player_engine`, `inputstream_behavior`, `stream_mode`, stripped-tag logs, segment 403/404, connection-error retries. Kept at INFO: server start, watchdog start, `STOPPING PLAYER`, stall kills, manifest 404, upstream 403/404 on manifests.

---

## [1.1.0] — 2026-10-04

Major reliability pass for IPTV live HLS (Xtream-style streams via JetExtractors).

### Added

- **Custom upstream headers** — headers travel as base64url JSON (`?h=...`) on the plugin URL; legacy `|Key=Value` suffixes still merged
- **Chrome default UA** + portal Referer when no headers supplied (never blank Referer)
- **Stall watchdog**
  - Per-request: close hung proxied connections after N seconds with no client data
  - Global: stop the Kodi player if the player is running but no media bytes flowed for N seconds
  - Setting: *Kill stream after N seconds with no data* (default 25)
- **Dead-stream cache** — manifest404 marks the URL dead for 60s; follow-ups fail fast
- **Player stopped on dead streams** — manifest404 / media-health stop calls `xbmc.Player().stop()` + notification instead of leaving a frozen frame
- **Player engine setting** — `ffmpegdirect` | `adaptive` | `none` (for live audio/PTS issues try `adaptive`)
- **HLS stream mode setting** — `realtime` (default) | `timeshift` for ffmpegdirect
- **Playlist normalization**
  - Strip `#EXT-X-START` and `#EXT-X-PROGRAM-DATE-TIME` (huge ffmpeg `start:` / ActiveAE desync)
  - Rewrite `URI="..."` in `#EXT-X-MEDIA` / `#EXT-X-MAP` / I-frame tags through the proxy (audio renditions)
  - One INFO dump of the upstream playlist per URL for diagnosis
- **Robust payload classification** — Content-Type + `#EXTM3U` + MPEG-TS `0x47` sniffing; wrong Content-Type on segments no longer parsed as m3u8
- Threading HTTP server (`ThreadingHTTPServer`) + HTTP/1.1 keep-alive + `requests.Session` pooling
- `docs/README.md` and this changelog

### Changed

- Manifest retries capped at **4 × 0.4s** (was 20 × 2–3s) —404 on live m3u8 usually means the portal killed the stream
- Segment requests **fail fast** (1 attempt) so ffmpeg re-fetches the playlist for fresh tokens
- Error responses use `Connection: close`
- Upstream HTTP timeout 30s → 12–15s
- Hop-by-hop headers and `Range` on manifests not forwarded upstream
- Playlist cache TTL 1.5s → **0.5s**
- Request header logs at DEBUG (less noise under load)
- Client disconnect / broken pipe handled quietly (no traceback spam)
- `xbmcaddon.Addon(id="plugin.video.jetproxy")` for settings reads

### Fixed

- JetProxy hardcoded Firefox UA + blank Referer → many Xtream servers returned HTML instead of m3u8 (video failed in Kodi while VLC worked)
- `jetproxy://` links created with `headers=None` — extractors now attach Chrome UA + portal Referer/Origin
- Single-threaded proxy blocked playlist refreshes during large segment downloads → stalls after 10–30s
- ffmpegdirect timeshift left the player open on dead streams
- No-audio / huge `ActiveAE - large audio sync error` on some live IPTV (partial — some sources have broken audio PTS that require a different portal)

---

## [1.0.7] — prior

Baseline JetProxy as shipped by t4ils:

- Local proxy on `127.0.0.1:49777`
- `plugin://plugin.video.jetproxy/play/<url>` routing
- inputstream.ffmpegdirect integration (`Always On` / `Always Off` / `Always Ask`)
- Basic m3u8 URL rewrite through the proxy
- Hardcoded Firefox UA + blank Referer on upstream requests
- Retry slider for 403/404 (default 20)

---

## Upgrade notes

1. Restart Kodi (or disable/enable JetProxy) after updating so `server.py` / `main.py` reload.
2. First run writes no extra profile files; settings live under the addon’s settings.xml.
3. If audio breaks on a stream that used to work, set **Player engine → adaptive**.
4. Watchdog kill timeout is configurable; set `0` equivalent by choosing the lowest slider value only if you must disable early stops — prefer fixing the source instead.
