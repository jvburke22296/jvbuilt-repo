import sys
import os
import xbmc
import xbmcaddon

ADDON_ID = "plugin.video.madtitansports"
ADDON = xbmcaddon.Addon(id=ADDON_ID)
addon_path = ADDON.getAddonInfo("path")

if addon_path not in sys.path:
    sys.path.insert(0, os.path.join(addon_path, "resources", "lib"))


_orig_addon = xbmcaddon.Addon

def _addon_with_context(id=None):
    if id is None:
        return _orig_addon(ADDON_ID)
    return _orig_addon(id)

xbmcaddon.Addon = _addon_with_context

from resources.lib.tool import log

# gui_layout setting index -> (xml file, nav mode)
# nav mode: 'classic' (Right enters widgets) or 'hub' (Up enters widgets)
LAYOUTS = {
    '0': ('home.old.xml', 'classic'),  # Minimal (Simple Layout)
    '1': ('home.hub.xml', 'hub'),          # Hub (Tile Carousel)
    '2': ('home.billboard.xml', 'classic'),  # Billboard (Hero)
    '3': ('home.xml', 'classic'),          # Classic (Top Nav)
    '4': ('home.sidebar.xml', 'classic'),    # Sidebar (Icon Rail)
    
}


def main():
    log(f"gui_launcher.py started with args: {sys.argv}")

    try:
        from resources.lib.changelog_window import check_and_show_changelog
        check_and_show_changelog(addon_path)
    except Exception as e:
        log(f"Changelog check failed: {e}")

    try:
        from resources.lib.gui_main import MadTitanGUI
        layout_idx = ADDON.getSetting('gui_layout') or '0'
        xml_file, nav_mode = LAYOUTS.get(layout_idx, ('home.xml', 'classic'))
        gui = None
        if xml_file != 'home.xml':
            # alternate layout: only load if the XML exists for the active skin path
            skin = xbmc.getSkinDir()
            layout_paths = [
                os.path.join(addon_path, 'resources', 'skins', skin, '720p', xml_file),
                os.path.join(addon_path, 'resources', 'skins', 'Default', '720p', xml_file),
            ]
            if any(os.path.exists(p) for p in layout_paths):
                gui = MadTitanGUI(xml_file, addon_path, defaulttheme=False, layout=nav_mode)
            else:
                log(f'gui_layout={layout_idx} but {xml_file} missing, falling back to classic')
        if gui is None:
            gui = MadTitanGUI('home.xml', addon_path, defaulttheme=False, layout='classic')
        gui.doModal()
        del gui
    except Exception as e:
        import xbmcgui
        xbmcgui.Dialog().ok('Mad Titan Sports', f'GUI failed to start:\n{e}')
        log(f"gui_launcher.py error: {e}")

    log("gui_launcher.py finished")


if __name__ == "__main__":
    main()
