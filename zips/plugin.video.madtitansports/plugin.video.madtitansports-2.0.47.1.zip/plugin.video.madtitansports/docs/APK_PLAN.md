# MAD Titan Sports — Standalone Android APK Plan

> Goal: ship a sideloadable Android APK of the addon's core (scrape → resolve → play), reusing the existing Python code. One simple UI, totally different from the addon skins. Non-Python code allowed where it functions better.

## Architecture Decision: Python core + Native Android shell

**Chaquopy** (runs Python inside a native Android app) + **Jetpack Compose** UI + **Media3 ExoPlayer**.

| Layer | Tech | Why |
|---|---|---|
| Scrapers, debrid, TMDB, menu data | **Python** (existing addon code, nearly untouched) | This is the addon's value; 173k lines already written and working |
| Kodi API compatibility | **Kodi shim** (small Python stubs: `xbmc.py`, `xbmcaddon.py`, `xbmcvfs.py`, `xbmcgui.py`, `xbmcplugin.py`) | jetextractors uses `xbmc` in 108/111 files — mostly logging/settings/paths. Shim maps them to Python `logging`, a JSON settings file, and app cache dirs |
| UI (1 screen flow) | **Kotlin / Jetpack Compose** (Material3, dark, cyan+red accent) | Python UI kits (Kivy/Flet) have weak HLS playback and no custom HTTP headers — this is the one place Kotlin pays for itself |
| Video playback | **Media3 ExoPlayer** | Handles HLS/DASH/live natively, supports per-stream custom headers (Referer/User-Agent), PiP, track selection. Kodi's inputstream equivalents |
| Packaging | **Chaquopy Gradle plugin** → `gradlew assembleDebug` APK | Standard Android build; APK sideloaded to phone/TV |

Rejected: Flet/Kivy (player can't send stream headers → many links break); full Kotlin rewrite (throws away working Python).

## Project location

New folder next to Kodi, Kodi addon stays untouched (code is **copied**, never moved):
```
C:\Users\Finerty-PC\Desktop\KODI_21v\MADTitan_App\
├── app\                      # Android project (Gradle, Kotlin, Compose)
├── app\src\main\python\      # Chaquopy Python source (the reused addon code)
│   ├── kodi_shim\            # xbmc/xbmcaddon/xbmcvfs/xbmcgui/xbmcplugin stubs
│   ├── jetextractors\        # vendored from script.module.jetextractors/lib
│   ├── plugins\              # selected addon plugins (jetextractors wrapper, sportvideo, …)
│   └── api.py                # clean facade: functions Kotlin calls, JSON in/out
└── docs\ (plan, notes)
```

## Reuse vs cut

**Reuse (Python):** `script.module.jetextractors` (~27k lines, 111 files), addon `resources/lib/plugins/jetextractors.py` wrapper, `sportvideo.py`, search/TMDB modules, later: IPTV parsers, debrid clients.
**Cut:** 5 skin layouts / all GUI mixins / `service.py` / `gui_main.py` (replaced by one Compose flow), microjen scrapers (later), `jetproxy` addon (later — if a stream needs manifest rewrite, the module's own local `xyz_proxy` runs on-device as localhost proxy).
**Kotlin gets:** activity, navigation, player, PiP, settings screen, error/loading states.

## Phases

### Phase 0 — Toolchain + hello APK (fail fast)
1. Install Android Studio (bundled JDK + SDK).
2. Create project `com.madtitan.sports`, add Chaquopy plugin.
3. Compose screen button → calls Python `api.hello()` → shows returned string.
4. Build `assembleDebug`, sideload to phone (USB/adb), run.

**Done when:** APK installs on a device and a Kotlin screen displays text computed by bundled Python. Everything after this is additive.

### Phase 1 — Port Python core (testable on PC, no device needed)
1. Copy shim + `jetextractors` package + needed `plugins/*.py` into `app/src/main/python/`.
2. Shim behavior: `xbmc.log` → `logging`; `xbmcaddon.Addon().getSetting` → JSON prefs file; `xbmcvfs.translatePath` → app dirs; dialogs = no-ops.
3. Write `api.py` facade returning plain dicts (JSON-safe):
   - `get_home()` → category list
   - `search(query)` → events (`{title, league, time, is_live}`)
   - `resolve(event_id)` → streams (`{server, quality, url, headers{}}`)
4. PC harness (`python tools/cli_test.py`) runs the same `api.py` on Windows — iterate until real streams resolve on desktop.

**Done when:** `python tools/cli_test.py "nba"` prints playable URLs with headers, without Kodi installed.

### Phase 2 — Compose UI (one flow)
1. Screen 1 **Home**: search bar + category chips (Live / Search / later Movies, IPTV).
2. Screen 2 **Results**: list rows — title, league·time, LIVE pill; pull-to-refresh, loading/error states.
3. Screen 3 **Sources**: bottom sheet — server + quality rows.
4. Kotlin→Python bridge class: `Python.getInstance().getModule("api")`, all calls on `Dispatchers.IO`.

**Done when:** tapping a search result on-device shows the addon's real sources.

### Phase 3 — Player (MVP milestone)
1. `PlayerActivity` + Media3 `PlayerView`: fullscreen, orientation, controls (play/pause/seek/live), error surface with retry.
2. Custom headers from `resolve()` applied via `DefaultHttpDataSource` request properties.
3. Picture-in-picture toggle; screen wake lock while playing.

**Done when:** a live stream plays end-to-end in the APK. **This is the working MVP — ship/test it before adding anything else.**

### Phase 4 — Grow (one feature per pass, verify each)
- More sources: sportvideo, DB stores (MyIPTV/Telegram/Sling/Foxxy), TMDB metadata.
- Debrid: Premiumize/Real-Debrid as thin Python REST clients (replaces ResolveURL; torrent→HTTP via their APIs, no torrent code on device).
- IPTV: port `m3u_parser`/xtream → channel list screen.
- Local `xyz_proxy` on-device for manifest-rewrite streams (network-security config allows loopback cleartext).
- Favorites/recent, settings screen (Kotlin prefs → JSON file read by Python), in-app updater.

### Phase 5 — Ship
- Release keystore, versioning, changelog, leanback/TV checks.
- Distribute APK directly (GitHub releases / direct file). **Play Store will not accept this category — sideloading is the channel** (same as everyone else's apps).

## Risks

| Risk | Mitigation |
|---|---|
| Chaquopy wheel gaps (pycryptodome, bs4) | Verify in Phase 0/1; requests/bs4/pycryptodome have Chaquopy wheels; swap to pure-Python fallback if not |
| jetextractors code assumes Kodi paths/special:// | Shim maps everything to app dirs |
| Streams need Referer/UA headers | ExoPlayer custom request properties (Phase 3) — main reason we chose it over Flet |
| Streams needing manifest rewrite | Local localhost proxy module (Phase 4) |
| Python blocking UI | All `callAttr` on IO dispatcher |
| Scope creep (11 mixins) | Hard rule: MVP = Phase 0-3 only, then one feature per verified pass |

## Working rules (per Agents.md)
- Small verified steps; nothing documented until tested on device.
- Each completed phase gets a dated entry in `docs/GUI_STATUS.md` + Agent Log line in `docs/Agents.md` with model name.
