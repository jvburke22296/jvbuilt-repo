# Mad Titan Sports — GUI Redesign Plan & Progress

**Created:** 2026-10-06
**Agent:** opencode/big-pickle

> **Purpose:** Track ideas and progress for making the custom GUI (`resources/skins/Default/720p/home.xml`) more modern and visually appealing. Update the **Status** column and add a dated entry to the [Session Log](#session-log) as changes are made and verified in Kodi.

---

## Current State (baseline)

| Element | Current |
|---------|---------|
| Layout | Left list 500px + right preview panel 660px (both `posy 100`, `height 600`) |
| Background | Static `Background.png`, opaque |
| Border | Bright neon **lime** (`FF32FF32`) frame around preview panel |
| Accents | Hardcoded aqua (`FF00BFFF`), orange, red, yellow, lime — no single system |
| Header | 80px block, centered title `font40_title`, time left, close right |
| Focus | Solid `ButtonFocus.png` block highlight |
| Loading | Plain "Loading..." label text |
| Fonts | Host-skin fonts only (`font9`–`font40_title`); addon bundles no `font.xml` |

**Key constraint:** Kodi `WindowXML` (Kodi 21), not CSS. Rounded corners / glow / gradients require bundled PNG textures (nine-patch `<border>` supported). Typography is limited to the active Kodi skin's fonts unless we add a custom `font.xml`.

---

## Design Direction (proposed)

- **Base:** deep charcoal / near-black (`#0E1116`, `#151A21`) with subtle vertical gradient
- **Accent:** one primary (proposed electric cyan `#22D3EE` or violet `#8B5CF6`)
- **Live accent:** single reserved color for live/status only (proposed red `#FF3B3B`)
- **Surfaces:** translucent "glass" cards over a dynamic fanart backdrop
- **Movement:** light focus zoom + fade-ins; no heavy motion

---

## Idea Backlog

| # | Idea | Area | Impact | Effort | Status | Notes |
|---|------|------|--------|--------|--------|-------|
| 1 | Cohesive color palette (remove lime border, unify accents) | Theme | High | Low | ☑ Done | Lime chrome → cyan; NOW PLAYING → red |
| 2 | Dynamic focused-item fanart backdrop + dark scrim | Background | High | Med | ☑ Done | `Window.Property(preview_backdrop)` + cyan scrim |
| 3 | Semi-transparent glass preview panel | Panels | High | Low | ◐ In progress | Alpha scrims applied throughout |
| 4 | Rounded card textures (nine-patch) | Panels/Tiles | Med | Med | ☑ Done | `rounded_card/focus/pill.png` (+`<border>`) |
| 5 | Focus animation (zoom) + accent side-bar | List | Med | Low | ☑ Done | Zoom on menu row, poster + channel grids |
| 6 | Status pills for LIVE/FINAL/SCHEDULED | Live Sports | Med | Med | ☑ Done | `game_status_color` + pill chips; live=red/final=grey/sched=cyan |
| 7 | Skeleton shimmer for loading states | All panels | Med | Med | ☐ Idea | Replace "Loading..." text |
| 8 | Unified grid gutters + hover glow | Poster/Channel grids | Med | Low | ☑ Done | Unified 8px tile margins + rounded focus glow |
| 9 | Slim frosted header bar | Header | Low | Low | ☑ Done | 62px slim bar + cyan underline |
| 10 | Footer hint/status bar (Back/Select/clock) | Chrome | Low | Low | ◐ In progress | "PRESS SELECT TO OPEN" CTA chip added |
| 11 | Theme switch (OLED / Dark / Light) | Theme | Med | High | ☐ Idea | Setting + skin variants |
| 12 | Custom bundled fonts | Typography | Med | High | ☐ Idea | Add `font.xml` + TTFs |
| 13 | Custom scrollbar styling | All lists | Low | Med | ☐ Idea | |
| 14 | **Layout A — Billboard Hero** | Layout | High | Med | ☑ Done | In-Kodi verified |
| 15 | **Layout B — Sidebar Rail** | Layout | High | High | ☑ Done | In-Kodi verified — rail + submenu + content all working |
| 16 | **Layout C — Dashboard Split** | Layout | Med | Low | ☑ Done | Original layout, backed up as `home.layoutC.bak.xml` |
| 17 | Preview detail card (hero image + chips + action row) | Preview | High | Med | ◐ In progress | Backdrop + logo overlay + CTA chip done |
| 18 | **Layout D — Full-bleed Top Nav** | Layout | High | Med | ☑ Done | In-Kodi verified — tab bar + floating panel + full-bleed content |
| 19 | **Layout E — Hub (tile carousel)** | Layout | High | Med | ◐ In progress | Full-bleed fanart + widget shelves + icon-tile nav; "GUI Layout" setting switches E/classic; needs in-Kodi check |

**Status legend:** ☐ Idea · ◐ In progress · ☑ Done (verified in Kodi) · ✗ Dropped

---

## Layout Concepts (left menu + preview)

### A. Billboard Hero — *recommended*
- Slim header. Upper ~58% of screen is a full-width **hero** for the highlighted item: focused item's backdrop/fanart with a left→right dark gradient, large title, metadata chips (year/rating/genre OR teams/score/status), short plot/EPG, and a Play CTA.
- Left menu becomes a **compact translucent overlay column** (~300px) floating on the hero, not an opaque panel.
- Lower ~42% holds the relevant widget (live game list / poster carousel / channel logos) as a horizontal row.
- **Why:** cinematic, uses properties Python already sets (`preview_thumb/title/summary` + live/tmdb/tvnet props). Mostly `home.xml`.
- **Effort:** Med · **Backend:** none expected

### B. Sidebar Rail (Plex/Disney+ style)
- ~96px icon rail for top-level sections + ~320px submenu list + ~840px content area.
- App-like and clean; requires an icon mapping per section and some nav plumbing.
- **Effort:** High · **Backend:** likely nav/icon work

### C. Dashboard Split — *least work*
- Keep two columns but rebalance to list ~380px / preview ~840px; preview becomes a **detail card** (large 16:9 image, title, metadata chips, plot, action row).
- **Effort:** Low · **Backend:** none

### D. Full-bleed Top Nav
- Nav becomes top tabs; content fills full width. Largest change.
- **Effort:** High · **Backend:** likely JSON/menu structure
- **Status (2026-10-09):** Implemented in Default skin — horizontal tab bar (control 90) + floating submenu panel (control 100) + full-bleed content; no Python changes needed (reuses Layout B rail logic)

### Preview panel upgrades (applies to all layouts)
- Hero image + gradient scrim replacing the opaque black panel
- Metadata chips (year / rating / genre / teams)
- Action row (Play / Favorite)
- Live sports: scoreboard header with team-color gradient bar + status pill
- Movies: poster + rating/year chips + plot fade; Channels: logo + now/next ribbon

### Nav plumbing that MUST be preserved
Control IDs: `100` main list · `510` live game list · `520` movie grid · `530` channel grid · `531` settings list · `200` close · `201` restore. Keep `onleft/onright/onup/ondown` mappings consistent with any repositioning.

---

## Implementation Notes

- **Files likely touched:** `resources/skins/Default/720p/home.xml`, `resources/skins/Default/media/*`, and any Python that sets window properties (preview/backdrop) — e.g. `resources/lib/gui_main.py`, `gui_helpers.py`.
- **Estuary skin** (`resources/skins/estuary/...`) must be kept in sync — see GUI_STATUS.md.
- **Test both skins** and both GUI / non-GUI modes after any change.
- Keep changes incremental; verify each in Kodi before marking ☑.

---

## Session Log

### 2026-10-10 — Layout switcher expanded to 4 layouts + Hub backdrop/settings polish
- **Agent:** kilo/xiaomi/mimo-v2.5
- **Change:**
  - **GUI Layout setting now has 4 options**: Classic (Top Nav) / Hub (Tile Carousel) / Billboard (Hero) / Sidebar (Icon Rail). Verified Layout A + B backups copied to `home.billboard.xml` + `home.sidebar.xml` (backups kept). `gui_launcher.py` is now table-driven (`LAYOUTS` dict: setting index → xml file + nav mode) — adding a future layout = 1 dict line + 1 string.po entry + lvalues append. Missing XML safely falls back to Classic. All four XMLs validated with required control IDs.
  - **Hub fixes** (user feedback): settings grid got a full-width opaque backdrop + own header row (was a narrow panel letting the per-row "featured tool" mirror bleed around it); settings list widened to 1160px; removed accidental `onup` hijack on 531. Widget-mode backdrop is now flat near-black `#080A0C` (fanart hero + scrims only in default mode) so transparent icons/tiles no longer blend into fanart colors.
  - **Settings enum fix**: `lvalues` needs numeric string IDs — added `resources/language/resource.language.en_gb/strings.po` (32001-32004); previously showed garbage ("Programs").
- **Files modified:** `gui_launcher.py`, `resources/settings.xml`, `resources/language/resource.language.en_gb/strings.po` (new), `resources/skins/Default/720p/{home.hub.xml,home.billboard.xml,home.sidebar.xml}`
- **Status:** XML + py_compile verified; Hub fixes need in-Kodi confirmation

### 2026-10-10 — Layout E (Hub / tile carousel) + GUI Layout setting
- **Agent:** kilo/xiaomi/mimo-v2.5
- **Change:** New fifth layout concept + layout switcher:
  - **`home.hub.xml`** (new, `resources/skins/Default/720p/`): Apple TV / Google TV style — full-bleed focused-item fanart behind everything (top+bottom scrims for readability), slim 56px top bar (logo, clock, restore, close), floating rounded featured card per mode (scoreboard / movie / channel EPG), horizontal widget shelf under it (games `510` / posters `520` / channels `530` / settings `531`), and a **132×144 icon-tile carousel** (control `100`, horizontal) as the only nav along the bottom — section title strip above it. Focus zooms 110% with cyan underline.
  - **Nav difference:** Up from tiles enters the widget shelf, Down returns to tiles, Left/Right scroll tiles (classic layouts use Right/Left). Handled in `onAction` via `self._layout == 'hub'` (`__init__` new `layout` kwarg, default `'classic'`).
  - **New setting:** GUI Settings → "GUI Layout" (`gui_layout` enum: Classic Top Nav / Hub Tile Carousel). `gui_launcher.py` reads it, loads `home.hub.xml` (with file-existence fallback to `home.xml`) and passes `layout='hub'|'classic'`. Classic `home.xml` (Layout D) untouched — Hub is purely additive.
  - Hub XML has no control 90 → existing rail Python auto-disables via `_rail_available` guard.
- **Files modified:** `resources/skins/Default/720p/home.hub.xml` (new), `resources/lib/gui_main.py` (`layout` kwarg + hub branches in `onAction`), `gui_launcher.py` (layout selection), `resources/settings.xml` (`gui_layout` enum)
- **Status:** XML + py_compile verified — needs in-Kodi confirmation (hub nav up/down, setting switch both ways)

### 2026-10-09 — Layout D (Full-bleed Top Nav) implemented in Default skin
- **Agent:** kilo/xiaomi/mimo-v2.5
- **Change:** Rewrote `resources/skins/Default/720p/home.xml` to Layout D:
  - **72px top bar**: app logo, horizontal root-section **tab bar** (control `90`, 150px tabs with icon + label, live-dot, cyan underline + zoom on focus), clock, Tap-to-Restore, Close. Window slides down from the top on open.
  - **Floating submenu panel** (control `100`, 360×600 rounded card at x=24/y=96): section title + counter + labeled rows — floats over the content like a drawer.
  - **Full-bleed content** (y=72, 1280×648): hero backdrop fills the entire width behind the floating panel; text block sits right of the panel; Live Sports / TMDB / TV Networks panels re-flowed to the full-width region starting at x=392 (clear of the floating panel).
  - **Nav:** tab bar ↔ submenu via `onup/ondown` (and `onleft` on the submenu returns to tabs); tab click jumps to a section from anywhere (same handler as Layout B's rail — control `90` reused, orientation-agnostic); **zero Python changes**.
  - **Backup:** verified Layout B saved as `home.layoutB.bak.xml`.
- **Files modified:** `resources/skins/Default/720p/home.xml`
- **Status:** Layout D in-Kodi verified by user (2026-10-09). Estuary mirror pending.

### 2026-10-09 — Layout B (Sidebar Rail) implemented in Default skin
- **Agent:** kilo/xiaomi/mimo-v2.5
- **Change:** Rewrote `resources/skins/Default/720p/home.xml` to Layout B (Plex/Disney+ style):
  - **96px icon rail** (new control `90`, far left): always shows root sections as icon tiles (42px icon + micro-label), pulsing live-dot on Live Sports, cyan accent bar + 106% zoom on focus, app logo on top, clock + Tap-to-Restore + Close stacked at the bottom.
  - **320px submenu column** (control `100`): section title (`section_title` property, Anton display font) + item counter + labeled rows with icons; same rounded focus/zoom treatment.
  - **864px content area** (`x=416`): full-height hero (default mode) and re-flowed Live Sports / TMDB / TV Networks panels; all widget control IDs preserved (`500/510/520/530/531`).
  - **Nav:** rail↔submenu via `onleft/onright`; rail click jumps directly to that root section from anywhere (pops back to root first if inside a submenu); rail selection mirrors main-list selection at root level and vice versa (250ms poll); Back/close/context/state-restore behavior unchanged.
  - **Python (`gui_main.py`):** new `populate_rail()` (guarded — skins without control 90, e.g. Estuary mirror, disable the rail permanently via `_rail_available`), rail sync in `_poll_tick`, rail click handler in `onClick`, `_active_rail_idx`/`_pending_section_title` tracking, submenu header now shows the entered folder's name instead of the first child item's title.
  - **Backup:** Layout A saved as `home.layoutA.bak.xml`.
- **Files modified:** `resources/skins/Default/720p/home.xml`, `resources/lib/gui_main.py`
- **Status:** Layout B in-Kodi verified by user (2026-10-09) — rail + submenu + content all working. Estuary skin mirror pending.
- **Follow-up note:** rail + labeled submenu showing the same root items at top level takes a moment to get used to (intentional dual-view; rail becomes the section jumper once inside a submenu)

### 2026-10-06 — Settings preview restyle + per-mode header tags
- **Agent:** opencode/big-pickle
- **Change:** Settings/tools rows (control 531) got the same rounded treatment as the grids — `rounded_card` / `rounded_focus` tiles, 102% focus zoom, cyan scrolling values, and separators render as cyan tag chips (`is_separator` property). Header tag color is now property-driven (`tvnet_tag_color`/`tvnet_tag_text`): cyan for networks/File IPTV/JetExtractor modes, amber for Addon Settings + store-filter previews.
- **Files modified:** `resources/lib/gui_tools.py`, `resources/lib/gui_main.py`, `resources/skins/Default/720p/home.xml`
- **Status:** XML + py_compile verified — needs in-Kodi confirmation

### 2026-10-06 — Hero/pop batch: glow + panel tags + live pulse + menu polish + custom font
- **Agent:** opencode/big-pickle
- **Change:** "Make it stand out" batch (user-selected):
  - **Custom display font:** added `resources/skins/Default/font.xml` (this GUI family is built for the classic Default skin font scale, which was missing — everything was rendering at one fallback size). Defines `font9..font60` at a tuned 720p scale (NotoSans) plus new **Anton** (OFL) display faces `display_22/28/38/52`. Bundled `resources/skins/Default/fonts/{NotoSans-Regular,Anton-Regular}.ttf`. Also registered the display faces in the active skin's `addons/skin.estuary/xml/Font.xml` (Default + Arial fontsets) and copied `Anton-Regular.ttf` to `skin.estuary/fonts/` so the names resolve regardless of which font source is authoritative.
  - Applied Anton to the header title and hero title; the new scale gives real size gradation across menus/panels (was single fallback size).
  - **Hero glow + panel tags:** `hero_glow.png` (vertical cyan gradient, gentle pulse) washes the hero bottom edge. Panel headers become colored tag chips — LIVE SPORTS (red/white), NOW PLAYING (ochre/white), networks title (cyan/dark) — sub-headers retitled TRENDING / CHANNELS.
  - **Live pulse indicators:** `dot_live.png` red pulsing dot on the LIVE SPORTS menu row (`is_live` ListItem property set in `populate_list`) + red pulsing LIVE chip on the scoreboard when any game is in progress (`live_any_live` window property).
  - **Menu polish:** cyan `MAD TITAN` wordmark pill at the menu top, list shifted down, `● N CATEGORIES` counter at bottom (`menu_count` property).
- **Files modified:** `resources/skins/Default/font.xml` (new), `resources/skins/Default/720p/home.xml`, `resources/lib/gui_main.py`, `resources/lib/gui_live_sports.py`, 2 new PNGs in `media/`, 2 fonts in `fonts/`, `addons/skin.estuary/xml/Font.xml` + `fonts/Anton-Regular.ttf`
- **Status:** XML + py_compile verified — needs in-Kodi confirmation (esp. font sizes and Anton rendering)

### 2026-10-06 — Plan created
- **Agent:** opencode/big-pickle
- **Change:** Created this redesign plan + idea backlog; no code changes yet.
- **Files modified:** `docs/GUI_REDESIGN.md` (new)
- **Status:** Plan only — nothing implemented

### 2026-10-06 — Layout concepts added
- **Agent:** opencode/big-pickle
- **Change:** Added 4 layout concepts (Billboard Hero / Sidebar Rail / Dashboard Split / Top Nav) + preview detail-card upgrades; added backlog items 14–17. User approved theme ideas and requested layout options.
- **Files modified:** `docs/GUI_REDESIGN.md`
- **Status:** Plan only — pending user layout choice

### 2026-10-06 — Rounded tiles, focus zoom, status pills, gutters (items 4/5/6/8)
- **Agent:** opencode/big-pickle
- **Change:** Batch of four approved visual upgrades:
  - **Rounded textures:** generated nine-patch PNGs `rounded_card.png` (subtle fill), `rounded_focus.png` (cyan stroke + fill), `rounded_pill.png` (white chip) via System.Drawing; applied with `<border>18</border>` to main-menu rows, game rows, movie posters, and channel tiles.
  - **Focus zoom:** subtle `zoom` (104–106%, quadratic-out, `visiblechange`) on the main-menu row, movie-poster grid, and channel grid via wrapped groups.
  - **Status pills:** game rows now show LIVE/FINAL/SCHEDULED as colored chips — `gui_live_sports.py` sets `game_status_color` (red `FF3B3B` live, grey `888888` final, cyan `22D3EE` scheduled); status text is now plain (colored-markup removed). Top-game `live_status_color` unified to same palette.
  - **Grid gutters:** poster + channel tiles unified to symmetric 8px margins (channel logo 100→102 at x8).
- **Files modified:** `resources/lib/gui_live_sports.py`, `resources/skins/Default/720p/home.xml`, 3 new PNGs in `resources/skins/Default/media/`
- **Status:** XML + py_compile + texture loads verified — needs in-Kodi confirmation

### 2026-10-06 — Hero upgrades: fanart backdrop + logo overlay + CTA, cyan cleanup
- **Agent:** opencode/big-pickle
- **Change:** Continued Layout A polish (backlog items 1/2/10/17):
  - New `preview_backdrop` window property (`gui_main.py` `update_preview`) = focused item's 16:9 fanart (falls back to thumb) — fixes letterboxed logos in the hero by filling the full 968×658 region.
  - Hero now = fanart backdrop + category logo/poster overlay (top-right, fades in) + soft scrim + "PRESS SELECT TO OPEN" cyan CTA chip (bottom-right).
  - Leftover lime chrome (Tap to Restore / Close buttons) → cyan `22D3EE`; NOW PLAYING status → red `FF3B3B` (reserved live/status accent), both in `home.xml` and the guidedata schedule line in `gui_main.py`.
- **Files modified:** `resources/lib/gui_main.py`, `resources/skins/Default/720p/home.xml`
- **Status:** XML + py_compile verified — needs in-Kodi visual confirmation

### 2026-10-06 — Layout A (Billboard Hero) implemented in Default skin
- **Agent:** opencode/big-pickle
- **Change:** Rewrote `resources/skins/Default/720p/home.xml` to Layout A:
  - Slim 62px header: logo + "MAD TITAN SPORTS", clock right, cyan accent underline
  - Left menu is now a compact floating translucent column (310px) with cyan accent-bar focus, replacing the big opaque 500px list
  - Right region (968px) is a full-bleed **hero**: focused item image (`preview_thumb`) + dark scrim + bottom title/summary block
  - Reworked live_sports / tmdb_movies / tv_networks panels to fill the wider right region
  - Cyan (`#22D3EE`) replaces the lime neon border as the primary accent
- **Preserved:** control IDs `100/200/201/500/510/520/530/531/999/4000` and all `onleft/onright/onup/ondown` + `preview_mode` visibility conditions
- **Backup:** original saved as `resources/skins/Default/720p/home.layoutC.bak.xml`
- **Files modified:** `resources/skins/Default/720p/home.xml`
- **Status:** Layout A in-Kodi verified by user (2026-10-06) — hero upgraded to fanart backdrop afterward (see next entry). Estuary skin mirror pending.
- **Follow-ups:** hero backdrop uses `preview_thumb` (may letterbox for small logos); consider true fanart backdrop property later

### 2026-10-06 — Stray `[/B]` in menu titles fixed
- **Agent:** opencode/big-pickle
- **Root cause:** (1) server JSON uses mis-nested markup, e.g. `[COLORcoral][B]Extractor Sites[/COLOR][/B] Channels`; (2) the focused main-menu layout ALSO wrapped the label in `[B]$INFO[ListItem.Label][/B]`, nesting inside the already-bolded label and leaking `[/B]` on highlight.
- **Fix:** `fix_kodi_markup()` now (1) re-balances COLOR/B/I/U nesting, (2) moves all B/I/U tags to the outer edges of the whole label while keeping colors inline, (3) drops orphan closers — applied to main list labels (`populate_list`) and `preview_title`. Also removed the extra `[B]...[/B]` wrapper from the focused main-menu label in `home.xml`.
- **Files modified:** `resources/lib/gui_helpers.py`, `resources/lib/gui_main.py`, `resources/skins/Default/720p/home.xml`
- **Status:** Fixed — confirmed clean on focus and unfocus in-Kodi by user.

---

## Changelog

_(Add dated entries here when redesign changes are implemented and verified.)_
