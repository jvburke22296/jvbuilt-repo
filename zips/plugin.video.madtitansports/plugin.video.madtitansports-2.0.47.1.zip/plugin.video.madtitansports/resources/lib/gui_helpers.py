from resources.lib.sports_scope import scope_response
import re
import json
import base64
import urllib.parse

ADDON_ID = "plugin.video.madtitansports"


def store_refresh_notify(title, message, time_ms=3000):
    """Show a store-refresh banner only if store_refresh_notifications is enabled."""
    import xbmcaddon
    import xbmcgui
    try:
        enabled = xbmcaddon.Addon(id=ADDON_ID).getSettingBool("store_refresh_notifications")
    except Exception:
        enabled = True
    if enabled:
        xbmcgui.Dialog().notification(title, message, icon=xbmcgui.NOTIFICATION_INFO, time=time_ms)


def strip_color_tags(text):
    if not text:
        return ''
    text = re.sub(r'\[/?COLOR[^\]]*\]', '', text)
    text = re.sub(r'\[/?B\]', '', text)
    text = re.sub(r'\[/?I\]', '', text)
    return text.strip()


_MARKUP_TAG_RE = re.compile(r'\[(/?)(COLOR[^\]]*|B|I|U)\]', re.IGNORECASE)


def fix_kodi_markup(text):
    """Make Kodi inline markup render cleanly: colors kept inline, style
    tags (B/I/U) hoisted to the outer edges of the whole string.

    Server JSON often has mis-nested markup like
    '[COLORcoral][B]X[/COLOR][/B] Channels' where Kodi drops the color and
    renders an orphan '[/B]' literally at the end. Kodi can also leak
    mid-string '[/B]'. Re-balancing tags first, then moving B/I/U to the
    string boundaries avoids both problems.
    """
    if not text or '[' not in text:
        return text or ''
    # 1) Re-balance so every opener has a matching closer in nesting order.
    balanced = []
    stack = []
    pos = 0
    for m in _MARKUP_TAG_RE.finditer(text):
        balanced.append(text[pos:m.start()])
        pos = m.end()
        closing = m.group(1) == '/'
        tag = m.group(2)
        name = 'COLOR' if tag.upper().startswith('COLOR') else tag.upper()
        if not closing:
            stack.append(name)
            balanced.append(f'[{tag}]')
        elif name in stack:
            while stack and stack[-1] != name:
                balanced.append(f'[/{stack.pop()}]')
            if stack and stack[-1] == name:
                stack.pop()
                balanced.append(f'[/{tag}]')
        # stray closing tag (no matching open) is dropped
    balanced.append(text[pos:])
    while stack:
        balanced.append(f'[/{stack.pop()}]')
    balanced = ''.join(balanced)

    # 2) Drop style tags from the middle and collect which styles were used.
    styles = set()
    out = []
    pos = 0
    for m in _MARKUP_TAG_RE.finditer(balanced):
        out.append(balanced[pos:m.start()])
        pos = m.end()
        closing = m.group(1) == '/'
        tag = m.group(2)
        name = 'COLOR' if tag.upper().startswith('COLOR') else tag.upper()
        if name in ('B', 'I', 'U'):
            styles.add(name)
            continue
        out.append(f'[/{tag}]' if closing else f'[{tag}]')
    out.append(balanced[pos:])
    middle = ''.join(out).strip()

    # 3) Wrap the whole string in the styles that were requested.
    prefix = ''.join(f'[{s}]' for s in ('B', 'I', 'U') if s in styles)
    suffix = ''.join(f'[/{s}]' for s in ('U', 'I', 'B') if s in styles)
    return prefix + middle + suffix


def get_route_for_item(item):
    link = item.get('link', '')
    item_type = item.get('type', '')
    pvr_search = item.get('pvr_sport_search', '')
    file_iptv = item.get('file_iptv', '')
    sportjetextractors = item.get('sportjetextractors', '')

    if pvr_search:
        return ('pvr_search', pvr_search)

    if file_iptv:
        country = item.get('country', '*')
        if file_iptv == 'recent':
            return ('file_iptv_recent', '')
        elif file_iptv == '*':
            return ('file_iptv_search_country', '')
        else:
            return ('file_iptv_search', file_iptv)

    search_music = item.get('search_music', '')
    if search_music:
        return ('search_music', search_music)

    ytdlp = item.get('ytdlp', '')
    if ytdlp == 'search':
        return ('youtube_search', '')
    elif ytdlp and ytdlp != 'search':
        return ('youtube_play', ytdlp)

    fmstream = item.get('fmstream', '')
    if fmstream.startswith('search'):
        return ('fmstream_search', fmstream)
    elif fmstream == 'featured':
        return ('fmstream_featured', '')
    elif fmstream.startswith('country'):
        return ('fmstream_country', fmstream)
    elif fmstream:
        return ('fmstream_country', fmstream)

    fmstream_next = item.get('fmstream_next', '')
    if fmstream_next:
        return ('fmstream_next', fmstream_next)

    espn = item.get('ESPN', '')
    if espn:
        return ('espn_plus', espn)

    jetextractors_settings = item.get('jetextractors_settings', '')
    if jetextractors_settings:
        return ('jetextractors_manage', jetextractors_settings)

    telegram_server_filter = item.get('telegram_server_filter', '')
    if telegram_server_filter:
        return ('telegram_filter', telegram_server_filter)

    homeiptv_server_filter = item.get('homeiptv_server_filter', '')
    if homeiptv_server_filter:
        return ('homeiptv_filter', homeiptv_server_filter)

    xtream = item.get('xtream', '')
    if xtream and isinstance(xtream, dict):
        action = xtream.get('action', '')
        address = xtream.get('address', '')
        username = xtream.get('username', '')
        password = xtream.get('password', '')
        cat = xtream.get('cat', '')
        if action in ('input', 'previous', 'clear'):
            return ('xtream_action', json.dumps({'action': action}))
        elif action in ('categories', 'category') and address:
            val = {'action': action, 'address': address, 'username': username, 'password': password}
            if cat:
                val['cat'] = cat
            return ('xtream_genres', json.dumps(val))

    mac = item.get('mac', '')
    if mac and isinstance(mac, dict):
        action = mac.get('action', '')
        address = mac.get('address', '')
        mac_addr = mac.get('mac', '')
        username = mac.get('username', '')
        password = mac.get('password', '')
        genre = mac.get('genre', '')
        page = mac.get('page', '')
        mac_link = mac.get('link', '')
        title = mac.get('title', '')
        if action in ('input', 'previous', 'clear'):
            return ('mac_action', json.dumps({'action': action}))
        elif action in ('genres', 'genre') and address:
            val = {'action': action, 'address': address, 'mac': mac_addr, 'username': username, 'password': password}
            if genre:
                val['genre'] = genre
            if page:
                val['page'] = page
            return ('mac_genres', json.dumps(val))
        elif action == 'play' and address:
            val = {'action': 'play', 'address': address, 'mac': mac_addr, 'username': username, 'password': password, 'link': mac_link}
            if title:
                val['title'] = title
            return ('mac_play', json.dumps(val))

    myiptv_remote = item.get('myiptv_remote', '')
    if myiptv_remote:
        if myiptv_remote == 'menu':
            return ('myiptv_remote_menu', '')
        elif myiptv_remote == 'search_input' or myiptv_remote == '*':
            return ('myiptv_remote_search', '')
        elif myiptv_remote == 'categories':
            return ('myiptv_remote_categories', '')
        elif myiptv_remote.startswith('genre/'):
            return ('myiptv_remote_genre', myiptv_remote)
        elif myiptv_remote == 'full_search_input':
            return ('plugin', f'plugin://{ADDON_ID}/myiptv_remote/full_search_input')
        elif myiptv_remote == 'recent':
            return ('plugin', f'plugin://{ADDON_ID}/myiptv_remote/recent')
        elif myiptv_remote.startswith('search/'):
            term = myiptv_remote.replace('search/', '', 1)
            return ('myiptv_remote_search_term', term)
        elif myiptv_remote.startswith('full_search/'):
            term = myiptv_remote.replace('full_search/', '', 1)
            return ('plugin', f'plugin://{ADDON_ID}/myiptv_remote/full_search/{term}')
        else:
            return ('plugin', f'plugin://{ADDON_ID}/myiptv_remote/{myiptv_remote}')

    sportvideo = item.get('sportvideo', '')
    if sportvideo:
        if sportvideo == 'menu':
            return ('sportvideo_menu', '')
        elif sportvideo == 'search_input' or sportvideo == '*':
            return ('sportvideo_search', '')
        elif sportvideo.startswith('menu/'):
            term = sportvideo.replace('menu/', '', 1)
            return ('sportvideo_search_term', urllib.parse.unquote(term))
        elif sportvideo.startswith('search/'):
            term = sportvideo.replace('search/', '', 1)
            return ('sportvideo_search_term', urllib.parse.unquote(term))
        elif sportvideo.startswith('play/'):
            return ('sportvideo_play', sportvideo)
        else:
            return ('sportvideo_play', f'play/{sportvideo}')

    if sportjetextractors and isinstance(sportjetextractors, str):
        return ('jet_action', sportjetextractors)

    if sportjetextractors and isinstance(sportjetextractors, list):
        return ('list_pick', sportjetextractors)

    if not link or link == 'ignore':
        return None

    link_str = str(link)

    if link_str.startswith('tmdb/') or link_str.startswith('tmdb/tv'):
        return ('tmdb', link_str)

    if link_str.startswith('trakt/'):
        return ('trakt', link_str)

    if item_type == 'dir' and isinstance(link, str):
        return ('dir', link)

    if item_type == 'script' and isinstance(link, str):
        script_item = urllib.parse.quote_plus(link)
        return ('action', f'/run_script/{script_item}')

    if item_type == 'plugin' and isinstance(link, str):
        link_lower = link.lower()
        if link_lower == 'resolveurl_auth':
            return ('resolveurl_auth', '')
        elif link_lower == 'resolveurl_settings':
            return ('resolveurl_settings', '')
        else:
            plug_item = urllib.parse.quote_plus(link)
            return ('action', f'/run_plug/{plug_item}')

    if isinstance(link, list):
        return ('list_pick', link)

    if item_type == 'item' or item_type == '':
        link_str = str(link)
        if link_str.lower() == 'settings':
            return ('action', '/settings')
        elif link_str.lower() == 'clear_cache':
            return ('action', '/clear_cache')
        elif link_str.lower() == 'refresh_menu' or link_str.lower() == f'plugin://{ADDON_ID}/refresh_menu':
            return ('action', '/refresh_menu')
        elif link_str.lower().startswith('message/'):
            return ('action', f'/show_message/{link_str}')
        elif link_str.lower().startswith('pvr_sport_search/'):
            pvr_val = link_str[len('pvr_sport_search/'):]
            return ('pvr_search', pvr_val)
        elif link_str.lower().startswith('search_json/'):
            return ('action', f'/{link_str}')
        elif link_str.lower().startswith('plugin://'):
            return ('plugin', link_str)
        elif link_str.lower().startswith('is_ffmpeg://'):
            encoded = base64.urlsafe_b64encode(
                bytes(json.dumps({"link": link_str}), 'utf-8')
            ).decode('utf-8')
            return ('action', f'/play_video/{encoded}')
        else:
            encoded = base64.urlsafe_b64encode(
                bytes(json.dumps(item), 'utf-8')
            ).decode('utf-8')
            return ('action', f'/play_video/{encoded}')

    return None


def push_nav_stack(window):
    window.nav_stack.append({
        'items': window.items_data,
        'title': window.current_title,
        'url': window.current_url,
        'selected_idx': window.getControl(100).getSelectedPosition(),
    })


def navigate_to_results(window, items, title, url=''):
    push_nav_stack(window)
    window.items_data = items
    window.current_title = title
    window.current_url = url
    window.populate_list()
    window.update_preview(0)


def try_play_url(saved_url, source_label='pref'):
    """Try to play a saved stream URL. Returns True if playback started, False otherwise."""
    import xbmc
    import xbmcgui
    from resources.lib import loading_overlay
    from resources.lib.stream_prefs import StreamPreferences

    runnable_url = StreamPreferences().to_runnable_url(saved_url)
    is_links = saved_url.lower().startswith('links://')
    xbmc.Player().stop()
    loading_overlay.show()
    if saved_url.lower().startswith('http'):
        xbmc.Player().play(saved_url)
    else:
        xbmc.executebuiltin(f'RunPlugin({runnable_url})')
    if is_links:
        return True
    for _ in range(8):
        xbmc.sleep(500)
        # SAFETY: infobool, never xbmc.Player() — avoids the CloseFile/GIL
        # deadlock class on any calling thread.
        if xbmc.getCondVisibility('Player.HasMedia'):
            return True
    loading_overlay.close()
    xbmcgui.Dialog().notification('Stream Preferences', 'Preferred stream failed', xbmcgui.NOTIFICATION_WARNING, 3000)
    return False


def fetch_json(url, use_cache=False, db=None, session=None):
    if use_cache and db:
        cached = db.get(url)
        if cached:
            return scope_response(url, cached[0])
    try:
        response = scope_response(url, session.get(url, timeout=15).text)
        if use_cache and db:
            db.set(url, response)
        return response
    except Exception:
        return None
