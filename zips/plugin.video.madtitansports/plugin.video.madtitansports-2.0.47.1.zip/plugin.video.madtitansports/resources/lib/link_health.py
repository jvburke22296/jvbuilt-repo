from jetextractors.util.local_source_health import is_known_failed
"""Conservative direct HTTP link validation; unknown results remain visible."""
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlsplit, parse_qsl
import requests
import xbmcaddon
_cache = {}
def is_missing(url):
    if xbmcaddon.Addon(id="plugin.video.madtitansports").getSetting('hide_missing_http_links') != 'true':
        return False
    if is_known_failed(url):
        return True
    base, _, extra = str(url).partition('|')
    try:
        if urlsplit(base).scheme not in ('http', 'https'):
            return False
    except ValueError:
        return False
    previous = _cache.get(url)
    if previous and time.monotonic() - previous[0] < 900:
        return previous[1]
    missing = False
    try:
        headers = dict(parse_qsl(extra))
        # GET rather than HEAD: several streaming hosts reject HEAD requests.
        with requests.get(base, headers=headers, timeout=(2, 3), stream=True) as response:
            missing = response.status_code in (404, 410)
    except requests.RequestException:
        pass
    _cache[url] = (time.monotonic(), missing)
    return missing
def available_indices(urls):
    # Bound work per dialog; untested links are retained.
    count = min(len(urls), 8)
    with ThreadPoolExecutor(max_workers=8) as pool:
        missing = list(pool.map(is_missing, urls[:count]))
    return [i for i in range(len(urls)) if i >= count or not missing[i]]
