"""Small picture-in-picture preview while browsing the GUI.

Movies: 2s debounce on the Trending row fetches the TMDB/YouTube trailer key
and resolves it via YouTube's InnerTube ANDROID client (plugin.video.youtube
fallback), then plays windowed — xbmc.Player().play(url, li, windowed=True) —
so the GUI keeps focus.

Live channels: 1.5s debounce on the TV-networks grid (Sports Networks /
Live TV) matches the channel name against timstreams_data.db; direct links
play as-is, embed links go through the TimStreams extractor + ResolveURL.
Channels started from the context menu ("Play in Preview (Pin)") stay pinned
while scrolling; auto-preview never interrupts a pinned preview. Kodi has a
single video player, so only one PiP window can ever show at a time.

The skin's <control type="videowindow"> renders it, gated on the
madtitan_pip_on window property (set BEFORE the first frame: a hidden video
window starves the player buffer) plus the current preview_mode.
"""
import os
import re
import sqlite3
import threading

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.gui_helpers import strip_color_tags
from resources.lib.tool import log

ADDON_ID = 'plugin.video.madtitansports'
PROP = 'madtitan_pip_on'
DELAY = 2.0      # seconds a movie must stay highlighted before resolving
LIVE_DELAY = 1.5  # seconds a channel must stay highlighted
WATCHDOG = 15.0  # hide the window if no media appeared after play()
TS_DB = 'special://home/userdata/addon_data/script.module.jetextractors/timstreams_data.db'


class _PipPlayer(xbmc.Player):
    """Callbacks fire for every playback on the device, so each handler
    gates on the window's own _on flag."""

    def __init__(self, pip):
        xbmc.Player.__init__(self)
        self._pip = pip

    def onAVStarted(self):
        self._pip.av_started()

    def onPlayBackEnded(self):
        self._pip.finished()

    def onPlayBackStopped(self):
        self._pip.finished()

    def onPlayBackError(self):
        self._pip.finished()


class TrailerPIP:
    def __init__(self, win):
        self.win = win
        self._token = 0
        self._timer = None
        self._watch = None
        self._player = None
        self._on = False
        self._for = ''
        self._pending = ''
        self._muted = False
        self._pinned = False
        self._ts = None
        self._ts_mtime = -1

    def enabled(self):
        try:
            return xbmcaddon.Addon(ADDON_ID).getSetting('pip_trailers') == 'true'
        except Exception:
            return False

    def enabled_live(self):
        try:
            return xbmcaddon.Addon(ADDON_ID).getSetting('pip_live') == 'true'
        except Exception:
            return False

    # ------------------------------------------------------------------ api

    def schedule(self, m):
        """Highlight settled on movie m: arm (or keep) its trailer."""
        tid = str(m.get('id') or m.get('tmdb_id') or '')
        if not tid.isdigit():
            self.stop()
            return
        if self._pending == tid or (self._on and self._for == tid):
            return                       # already pending / playing this title
        self.stop()
        if not self.enabled():
            return
        media = 'tv' if m.get('media_type') == 'tv' else 'movie'
        token = self._token
        t = threading.Timer(DELAY, self._worker, args=(token, tid, media, m.get('title', '')))
        t.daemon = True
        self._timer = t
        self._pending = tid
        t.start()

    def schedule_channel(self, title):
        """Highlight settled on a TV-networks channel: auto-preview unless
        a preview was pinned from the context menu."""
        if self._pinned or not title:
            return
        if (self._on and self._for == title) or self._pending == title:
            return
        self.stop()
        if not self.enabled_live():
            return
        token = self._token
        t = threading.Timer(LIVE_DELAY, self._channel_worker, args=(token, title))
        t.daemon = True
        self._timer = t
        self._pending = title
        t.start()

    def pin_channel(self, title):
        """Context-menu 'Play in Preview': start (or switch to) this channel
        and keep it playing while the user scrolls."""
        if not title:
            return
        self.stop()
        self._pinned = True
        token = self._token
        t = threading.Timer(0.2, self._channel_worker, args=(token, title))
        t.daemon = True
        self._timer = t
        self._pending = title
        t.start()

    def is_pinned(self):
        return self._pinned

    def stop_if_unpinned(self):
        """Channel-grid leave: keep a pinned preview alive."""
        if self._pinned:
            return False
        return self.stop()

    def match_timstreams(self, title):
        """Guide channel name -> (stream_url, db name) from timstreams DB."""
        title_n = self._norm(strip_color_tags(title))
        if not title_n:
            return None
        m = self._ts_map()
        hit = m.get(title_n)
        if hit:
            return hit
        if len(title_n) >= 4:
            cands = [k for k in m if k.startswith(title_n) or title_n.startswith(k)]
            if cands:
                return m[min(cands, key=len)]
        return None

    def stop(self):
        """Cancel pending work and kill our preview (flags first, so the
        resulting stop callback is ignored). Player API only touched for our
        own stream — never queries on timer threads."""
        self._pinned = False
        self._token += 1
        self._pending = ''
        for attr in ('_timer', '_watch'):
            t = getattr(self, attr)
            if t is not None:
                try:
                    t.cancel()
                except Exception:
                    pass
                setattr(self, attr, None)
        was = self._on
        self.finished()
        if was and self._player is not None:
            try:
                self._player.stop()
            except Exception:
                pass
        return was

    def finished(self):
        if not self._on:
            return
        self._abort_proxies()   # FIRST: close proxy listen sockets (ISSUE_FREEZE)
        self._on = False
        self._for = ''
        try:
            self.win.setProperty(PROP, '')
        except Exception:
            pass
        if self._muted:
            self._set_mute(False)

    @staticmethod
    def _abort_proxies():
        """Callback-safe proxy teardown: preview streams play through the
        XYZ/Stream proxies registered in THIS (GUI) interpreter; closing
        their listen sockets at stop gives Kodi's post-close Stat an instant
        ECONNREFUSED instead of a 20s freeze."""
        try:
            from jetextractors.util.stream_proxy import abort_active_proxy
            abort_active_proxy()
        except Exception:
            pass
        try:
            from jetextractors.util.xyz_proxy import _shutdown_xyz_proxy
            _shutdown_xyz_proxy()
        except Exception:
            pass

    def av_started(self):
        if self._on:
            try:
                self.win.setProperty(PROP, 'true')
            except Exception:
                pass

    # -------------------------------------------------------------- worker

    def _worker(self, token, tid, media, title):
        try:
            if token != self._token:
                return
            from resources.lib.plugins.tmdb_plugin import TMDB_API
            detail = TMDB_API().get(f'{media}/{tid}', paginated=False, full_meta=True)
            key = self._pick_trailer(detail if isinstance(detail, dict) else None)
            if not key or token != self._token:
                return
            stream = self._resolve(key, token)
            if not stream or token != self._token:
                return
            if xbmc.getCondVisibility('Player.HasMedia') and not self._on:
                self.stop()              # real playback started meanwhile
                return
            self._start_play(stream, title, tid, token)
        except Exception as e:
            log(f'trailer_pip worker error: {e}', level=xbmc.LOGERROR)
            self.stop()

    def _channel_worker(self, token, title):
        try:
            if token != self._token:
                return
            hit = self.match_timstreams(title)
            if not hit or token != self._token:
                log(f'trailer_pip: no TimStreams match for "{strip_color_tags(title)}"')
                if self._pinned:
                    xbmcgui.Dialog().notification(
                        'Channel Preview',
                        f'No TimStreams match for {strip_color_tags(title)}',
                        xbmcgui.NOTIFICATION_WARNING, 3500)
                return
            url, ts_name = hit
            stream = self._resolve_live(url, token)
            if not stream or token != self._token:
                if self._pinned:
                    xbmcgui.Dialog().notification(
                        'Channel Preview', 'Could not resolve channel stream',
                        xbmcgui.NOTIFICATION_WARNING, 3500)
                return
            if xbmc.getCondVisibility('Player.HasMedia') and not self._on:
                self.stop()
                return
            self._start_play(stream, strip_color_tags(title) or ts_name, ts_name, token)
        except Exception as e:
            log(f'trailer_pip channel worker error: {e}', level=xbmc.LOGERROR)
            self.stop()

    def _start_play(self, stream, label, for_id, token):
        if self._player is None:
            self._player = _PipPlayer(self)
        try:
            if xbmcaddon.Addon(ADDON_ID).getSetting('pip_trailers_mute') == 'true':
                self._set_mute(True)
        except Exception:
            pass
        self._on = True
        self._for = for_id
        self.win.setProperty(PROP, 'true')   # window BEFORE first frame
        li = xbmcgui.ListItem(label=label)
        log(f'trailer_pip: windowed play "{label}"')
        self._player.play(stream, li, True)
        w = threading.Timer(WATCHDOG, self._watchdog, args=(token,))
        w.daemon = True
        self._watch = w
        w.start()

    def _watchdog(self, token):
        try:
            if token == self._token and self._on and not xbmc.getCondVisibility('Player.HasMedia'):
                log('trailer_pip: stream never started - hiding window')
                self.finished()
        except Exception:
            pass

    # ------------------------------------------------------------ internals

    @staticmethod
    def _pick_trailer(detail):
        videos = ((detail or {}).get('videos') or {}).get('results') or []
        first_en = first = None
        for v in videos:
            if v.get('site') != 'YouTube' or not v.get('key'):
                continue
            if v.get('type') not in ('Trailer', 'Teaser'):
                continue
            en = str(v.get('language', '')).startswith('en')
            if v.get('official') and en:
                return v.get('key')
            if en and first_en is None:
                first_en = v.get('key')
            if first is None:
                first = v.get('key')
        return first_en or first

    def _resolve(self, key, token=None):
        """Direct stream via YouTube's InnerTube ANDROID client — works on
        this Kodi's Python 3.8, where every yt-dlp release past 2024.12
        refuses to run (3.9+ required) and old ones fail all clients.
        Falls back to plugin.video.youtube when installed."""
        stream = self._innertube(key)
        if token is not None and token != self._token:
            return None
        if stream:
            log('trailer_pip: resolved via innertube android client')
            return stream
        if xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)'):
            return f'plugin://plugin.video.youtube/play/?video_id={key}'
        log('trailer_pip: no stream resolved (innertube failed, plugin.video.youtube not installed)',
            level=xbmc.LOGWARNING)
        return None

    @staticmethod
    def _innertube(key):
        import json
        payload = json.dumps({
            'context': {'client': {
                'clientName': 'ANDROID', 'clientVersion': '20.10.38',
                'androidSdkVersion': 30, 'androidRelease': '11',
                'hl': 'en', 'gl': 'US'}},
            'videoId': key, 'contentCheckOk': True, 'racyCheckOk': True,
        })
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'com.google.android.youtube/20.10.38 (Linux; U; Android 11) en_US',
        }
        for url in (
            'https://www.youtube.com/youtubei/v1/player?key=AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w',
            'https://www.youtube.com/youtubei/v1/player',
        ):
            try:
                r = requests.post(url, data=payload, headers=headers, timeout=10)
                if r.status_code != 200:
                    continue
                sd = (r.json() or {}).get('streamingData') or {}
                best, best_h = None, -1
                for f in sd.get('formats') or []:
                    u = f.get('url')
                    if not u:
                        continue
                    h = f.get('height') or 0
                    if h > best_h:
                        best, best_h = u, h
                if best or sd.get('hlsManifestUrl'):
                    stream = best or sd.get('hlsManifestUrl')
                    return stream + '|User-Agent=' + headers['User-Agent']
            except Exception as e:
                log(f'trailer_pip innertube error: {e}', level=xbmc.LOGWARNING)
        return None

    # -------------------------------------------------------- live channels

    @staticmethod
    def _norm(s):
        return re.sub(r'[^a-z0-9]', '', (s or '').lower())

    def _ts_map(self):
        """norm name -> (stream_url, db name), cached; reloads on DB change."""
        path = ''
        mtime = 0
        try:
            path = xbmcvfs.translatePath(TS_DB)
            mtime = os.path.getmtime(path)
        except Exception:
            pass
        if self._ts is not None and mtime and mtime == self._ts_mtime:
            return self._ts
        m = {}
        try:
            if path and os.path.exists(path):
                conn = sqlite3.connect('file:/%s?mode=ro' % path.replace('\\', '/'), uri=True)
                cur = conn.cursor()
                cur.execute('SELECT name, stream_url FROM channels')
                for name, url in cur.fetchall():
                    if name and url:
                        m[self._norm(name)] = (url, name)
                conn.close()
                log(f'trailer_pip: loaded {len(m)} TimStreams channels')
            else:
                log('trailer_pip: timstreams_data.db not found', level=xbmc.LOGWARNING)
        except Exception as e:
            log(f'trailer_pip: timstreams db error: {e}', level=xbmc.LOGWARNING)
        self._ts = m
        self._ts_mtime = mtime
        return m

    def _resolve_live(self, url, token=None):
        """Direct m3u8/mp4 play as-is; embeds via TimStreams extractor +
        ResolveURL (same chain the jet play path uses)."""
        low = url.lower()
        if '.m3u8' in low or '.mp4' in low:
            return url
        try:
            import resolveurl
            from jetextractors import extractor as jet_extractor
            from jetextractors.models import JetLink
            jl = JetLink.from_dict({'address': url, 'name': 'Preview',
                                    'resolveurl': True, 'extractor': 'TimStreams'})
            e = None
            try:
                e = jet_extractor.get_extractor('TimStreams')
            except Exception:
                e = None
            if e is not None:
                jl = e.get_link(jl)
                if token is not None and token != self._token:
                    return None
            if jl is None:
                return None
            if getattr(jl, 'resolveurl', False):
                hmf = resolveurl.HostedMediaFile(jl.address)
                if hmf:
                    return hmf.resolve()
                return jl.address
            return jl.address
        except Exception as e:
            log(f'trailer_pip live resolve error: {e}', level=xbmc.LOGWARNING)
            return None

    def _set_mute(self, mute):
        try:
            if mute:
                cur = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Application.GetProperties","params":{"properties":["muted"]},"id":1}')
                if '"muted":true' in cur.replace(' ', ''):
                    return               # viewer already muted: leave alone
                self._muted = True
            else:
                self._muted = False
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Application.SetMute","params":{"mute":%s},"id":1}' % ('true' if mute else 'false'))
        except Exception:
            pass
