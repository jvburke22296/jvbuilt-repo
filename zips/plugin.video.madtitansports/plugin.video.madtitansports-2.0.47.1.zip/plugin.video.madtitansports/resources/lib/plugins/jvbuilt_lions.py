"""JVBuilt's November 1 Lions entry: refresh playlist tokens before playing."""
import json, os, re, time
from urllib.parse import urlsplit, parse_qs
import requests, xbmc, xbmcgui, xbmcaddon, xbmcvfs
from resources.lib.plugin import Plugin

PLAYLIST = 'https://raw.githubusercontent.com/doms9/iptv/refs/heads/default/M3U8/kodi.m3u8'

def is_current(url):
    try:
        query = parse_qs(urlsplit(url.split('|')[0]).query)
        deadlines = [float(query[k][0]) for k in ('expires', 'e') if k in query]
        return not deadlines or min(deadlines) > time.time() + 30
    except (ValueError, TypeError):
        return False

def find_candidates(text):
    lines = text.splitlines(); found = []
    for index, label in enumerate(lines):
        if not label.startswith('#EXTINF'): continue
        title = label.rsplit(',', 1)[-1]
        if not all(word in title.lower() for word in ('vikings', 'lions', 'english')): continue
        url = next((line.strip() for line in lines[index + 1:index + 8] if line.startswith(('https://', 'http://'))), '')
        if url and is_current(url): found.append((title, url))
    found.sort(key=lambda item: ('STRMGATE' not in item[0].upper(), item[0]))
    return found

class JVBuiltLions(Plugin):
    name = 'jvbuilt_lions'
    priority = 100

    def routes(self, plugin):
        @plugin.route('/jvbuilt_sports')
        def sports_directory():
            import sys, xbmcplugin
            handle = int(sys.argv[1])
            item = xbmcgui.ListItem(label='Lions-Vikings LIVE')
            item.setProperty('IsPlayable', 'true')
            item.setArt({'thumb': 'special://home/addons/plugin.video.madtitansports/icon.png', 'fanart': 'special://home/addons/plugin.video.madtitansports/fanart.jpg'})
            xbmcplugin.addDirectoryItem(handle, 'plugin://plugin.video.madtitansports/jvbuilt_lions', item, isFolder=False)
            xbmcplugin.setContent(handle, 'videos')
            xbmcplugin.endOfDirectory(handle, cacheToDisc=False)

        @plugin.route('/jvbuilt_lions')
        def play():
            candidates = []
            try:
                response = requests.get(PLAYLIST, timeout=(4, 10))
                response.raise_for_status()
                candidates = find_candidates(response.text)
            except requests.RequestException:
                pass
            if not candidates:
                try:
                    profile = xbmcvfs.translatePath(xbmcaddon.Addon('plugin.video.madtitansports').getAddonInfo('profile'))
                    with open(os.path.join(profile, 'jvbuilt_lions_fallback.json'), encoding='utf-8') as handle:
                        saved = json.load(handle)
                    if is_current(saved.get('url', '')) and saved.get('url'):
                        candidates = [(saved.get('label', 'Lions-Vikings'), saved['url'])]
                except (OSError, ValueError):
                    pass
            if not candidates:
                xbmcgui.Dialog().notification('Lions-Vikings', 'No current English-labelled game link found')
                return
            title, url = candidates[0]
            item = xbmcgui.ListItem(label=title, path=url)
            item.setProperty('IsPlayable', 'true')
            item.setContentLookup(False)
            item.setMimeType('application/vnd.apple.mpegurl')
            from jetextractors.models import JetInputstreamAdaptive
            adaptive = JetInputstreamAdaptive.hls()
            # Requested live-edge delay for live Adaptive playback.
            adaptive.live_delay = 45
            adaptive.set_properties(item)
            import sys
            try:
                handle = int(sys.argv[1])
            except (IndexError, ValueError):
                handle = -1
            if handle >= 0:
                import xbmcplugin
                xbmcplugin.setResolvedUrl(handle, True, item)
            else:
                xbmc.Player().play(url, item)
