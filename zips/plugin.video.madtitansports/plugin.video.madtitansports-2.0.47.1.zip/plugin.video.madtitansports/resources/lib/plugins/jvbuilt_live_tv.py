"""Home widget: retain the PVR channel list, with MS NOW first."""
import json, os, re, sqlite3
from contextlib import closing
from urllib.parse import quote
import xbmc, xbmcgui, xbmcvfs
from resources.lib.plugin import Plugin

class JVBuiltLiveTV(Plugin):
    name='jvbuilt_live_tv'
    priority=100
    def routes(self,plugin):
        @plugin.route('/jvbuilt_live_tv')
        def channels():
            import sys, xbmcplugin
            handle=int(sys.argv[1])
            request={'jsonrpc':'2.0','id':1,'method':'PVR.GetChannels','params':{'channelgroupid':'alltv','properties':['thumbnail']}}
            response=json.loads(xbmc.executeJSONRPC(json.dumps(request)))
            entries=response.get('result',{}).get('channels',[])
            folder=xbmcvfs.translatePath('special://database/')
            databases=[n for n in os.listdir(folder) if re.fullmatch(r'TV\d+\.db',n)]
            paths={}
            if databases:
                database=max(databases,key=lambda n:int(n[2:-3]))
                with closing(sqlite3.connect('file:'+os.path.join(folder,database).replace('\\','/')+'?mode=ro',uri=True)) as connection:
                    group=connection.execute('SELECT sName,iClientId FROM channelgroups WHERE bIsRadio=0 AND iGroupType=1 ORDER BY idGroup LIMIT 1').fetchone()
                    group_path=quote(group[0],safe='')+'@'+str(group[1]) if group else 'All%20channels@-1'
                    query='SELECT c.idChannel,c.iUniqueId,c.sIconPath,k.sAddonID,k.iInstanceID FROM channels c JOIN clients k ON c.iClientId=k.idClient WHERE c.bIsRadio=0 AND c.bIsHidden=0'
                    for cid,uid,icon,addon,instance in connection.execute(query):
                        paths[cid]=('pvr://channels/tv/%s/%s@%s_%s.pvr'%(group_path,instance,addon,uid),icon)
            def preferred(entry):
                return re.sub(r'[^a-z0-9]','',entry.get('label','').lower()) not in ('msnow','msnbc')
            entries.sort(key=preferred)
            for entry in entries:
                if entry['channelid'] not in paths:continue
                path,icon=paths[entry['channelid']]
                item=xbmcgui.ListItem(label=entry['label'],path=path)
                item.setProperty('IsPlayable','true')
                item.setInfo('video',{'title':entry['label']})
                item.setArt({'thumb':icon or entry.get('thumbnail',''),'icon':icon or entry.get('thumbnail','')})
                xbmcplugin.addDirectoryItem(handle,path,item,isFolder=False)
            xbmcplugin.setContent(handle,'videos')
            xbmcplugin.endOfDirectory(handle,cacheToDisc=False)
