import json, re, os
import xbmcaddon, xbmcvfs
LEAGUES = {'nba', 'nfl', 'mlb', 'ncaaf', 'ncaab'}
def clean(value):
    return re.sub(r'\[[^\]]*\]', '', str(value)).strip().upper()
def scope_response(url, response):
    try:
        path = str(url).split('?')[0].lower()
        if path.endswith('/titansports_nfl.json'):
            return correct_nfl_times(response)
        if not (path.endswith('/sports/sports.json') or 'tvguide_sports' in path):
            return response
        data = json.loads(response)
        if path.endswith('/sports/sports.json'):
            data['items'] = [i for i in data.get('items', []) if any(str(i.get('link', '')).split('?')[0].endswith('/titansports_' + sport + '.json') for sport in LEAGUES)]
        else:
            names = {'ESPN HD', 'ESPN2 HD', 'ESPNEWS HD', 'ESPNU HD', 'ACC NETWORK', 'BIG TEN NETWORK HD', 'SEC NETWORK HD', 'FS1 FOX SPORTS 1 HD', 'FS2 FOX SPORTS 2 HD', 'MLB NETWORK HD', 'MLB NETWORK STRIKE ZONE HD', 'MLB NETWORK HD ALTERNATE', 'NBA TV HD', 'NFL NETWORK HD', 'NFL REDZONE HD', 'CBS SPORTS NETWORK HD'}
            data['items'] = [i for i in data.get('items', []) if clean(i.get('title2', i.get('ch_id', i.get('title', '')))) in names]
            profile = xbmcvfs.translatePath(xbmcaddon.Addon('plugin.video.madtitansports').getAddonInfo('profile'))
            with open(os.path.join(profile, 'national_channels.json'), encoding='utf-8') as f:
                nationals = json.load(f)
            present = {clean(i.get('title2', i.get('ch_id', ''))) for i in data['items']}
            data['items'].extend(i for i in nationals if clean(i.get('title2', i.get('ch_id', ''))) not in present)
            # Put a locally playback-tested route first; retain original routes as alternatives.
            try:
                with open(os.path.join(profile, 'verified_national_sources.json'), encoding='utf-8') as f:
                    verified = json.load(f).get('sources', {})
                for item in data['items']:
                    route = verified.get(clean(item.get('title2', item.get('ch_id', ''))))
                    if route:
                        original = item.get('link', [])
                        if isinstance(original, str): original = [original]
                        item['link'] = [route + '(Playback-tested CDNLiveTV)'] + [link for link in original if link != route]
            except (OSError, ValueError):
                pass

        return json.dumps(data)
    except Exception:
        return response

def correct_nfl_times(response):
    from datetime import datetime
    import pytz
    try:
        eastern = pytz.timezone('America/New_York')
        if datetime.now(eastern).strftime('%Y%m%d') != '20261101': return response
        profile = xbmcvfs.translatePath(xbmcaddon.Addon('plugin.video.madtitansports').getAddonInfo('profile'))
        with open(os.path.join(profile, 'nfl_schedule_20261101.json'), encoding='utf-8') as f: events = json.load(f)
        data = json.loads(response)
        for item in data.get('items', []):
            for event in events:
                teams = [c['team']['name'].lower() for c in event['competitions'][0]['competitors']]
                if not all(team in item.get('title', '').lower() for team in teams): continue
                kickoff = datetime.strptime(event['date'], '%Y-%m-%dT%H:%MZ').replace(tzinfo=pytz.UTC).astimezone(eastern)
                display = kickoff.strftime('%m/%d %I:%M %p').replace('11/01', '11/1').replace(' 0', ' ')
                item['title'] = re.sub(r'11/1 \d{1,2}:\d{2} [AP]M', display, item['title'])
                for guide in item.get('guidedata', []): guide['starttime'] = int(kickoff.timestamp())
                try:
                    with open(os.path.join(profile, 'nfl_candidate_backups.json'), encoding='utf-8') as f: backups = json.load(f)
                    route = backups.get(event['id'])
                    if route:
                        links = item.get('link', [])
                        if isinstance(links, str): links = [links]
                        item['link'] = [route] + [link for link in links if link != route]
                except (OSError, ValueError): pass

                break
        return json.dumps(data)
    except (OSError, ValueError, KeyError): return response
