"""Stage same-device user data before replacing a build. No Kodi imports."""
from pathlib import Path
import shutil
import sqlite3
import json
import hashlib
import xml.etree.ElementTree as ET
from contextlib import closing

GUI_BUILD_KEYS = {'filecache.memorysize', 'filecache.buffermode', 'filecache.readfactor', 'filecache.chunksize', 'locale.subtitlelanguage'}
SKIN_BUILD_KEYS = {'WidgetLimit', 'HubLimit', 'show.reflections', 'home.widgets.show.reflections', 'enableeffects', 'enableeffectssettings', 'home.netflix.autoplay.trailer', 'hide.homemenu.netflix.preview', 'hide.views.netflix.preview', 'skin_enableanimatedposters', 'skinhelper.enableanimatedposters', 'furniture.animatedposters', 'furniture.animatedfanarts'}
WIZARD_BUILD_KEYS = {'buildname', 'buildversion', 'latestversion', 'installed', 'extract', 'errors'}


def copy_file(source, destination):
    if source.is_symlink():
        raise ValueError('Refusing linked user data: ' + str(source))
    destination.parent.mkdir(parents=True, exist_ok=True)
    if source.suffix == '.db':
        # SQLite's backup API includes committed WAL data in a consistent snapshot.
        with closing(sqlite3.connect(str(source))) as src, closing(sqlite3.connect(str(destination))) as dst:
            src.backup(dst)
    else:
        # Android emulated storage forbids copying security/SELinux xattrs.
        shutil.copyfile(source, destination)


def copy_tree(source, destination):
    destination.mkdir(parents=True, exist_ok=True)
    for item in source.rglob('*'):
        if item.is_symlink():
            raise ValueError('Linked add-on requires manual recovery')
        target = destination / item.relative_to(source)
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif item.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(item, target)


def merge_settings(old, new, keep_build):
    original = ET.parse(old)
    incoming = ET.parse(new)
    for key in keep_build:
        node = original.getroot().find("setting[@id='%s']" % key)
        if node is not None:
            original.getroot().remove(node)
        replacement = incoming.getroot().find("setting[@id='%s']" % key)
        if replacement is not None:
            original.getroot().append(replacement)
    original.write(new, encoding='utf-8', xml_declaration=True)


def stage(home, payload, recovery):
    home, payload, recovery = map(Path, (home, payload, recovery))
    if home == payload or home in payload.parents or home == recovery or home in recovery.parents:
        raise ValueError('Recovery and stage must be outside the Kodi data folder')
    userdata = home / 'userdata'
    # Preserve every profile, account, source, library, favourite, pin and backup setting.
    # Build version/registry and platform performance configuration come from the new build.
    skipped = {'jvbuilt_setup.json', 'jvbuilt_performance.json'}
    protected = []
    for source in userdata.rglob('*'):
        if source.is_symlink():
            raise ValueError('Linked user data requires manual recovery')
        if not source.is_file():
            continue
        relative = source.relative_to(userdata)
        if source.name.endswith(('-wal', '-shm', '-journal')) or source.name.startswith('Addons') and source.suffix == '.db':
            continue
        if relative.as_posix() in skipped:
            continue
        destination = payload / 'userdata' / relative
        if relative.as_posix() == 'advancedsettings.xml' and destination.exists():
            previous = ET.parse(source)
            incoming = ET.parse(destination)
            for key in ('imageres', 'fanartres'):
                node = previous.getroot().find(key)
                if node is not None:
                    previous.getroot().remove(node)
                node = incoming.getroot().find(key)
                if node is not None:
                    previous.getroot().append(node)
            previous.write(destination, encoding='utf-8', xml_declaration=True)
            continue
        if destination.exists() and source.suffix == '.xml' and (relative.as_posix() == 'guisettings.xml' or relative.name == 'settings.xml' and relative.parts[0] == 'addon_data' and relative.parts[1] in ('skin.arctic.zephyr.mod', 'plugin.program.jvbuiltwizard')):
            keys = GUI_BUILD_KEYS if relative.as_posix() == 'guisettings.xml' else WIZARD_BUILD_KEYS if relative.parts[1] == 'plugin.program.jvbuiltwizard' else SKIN_BUILD_KEYS
            merge_settings(source, destination, keys)
        else:
            copy_file(source, destination)
            protected.append({'path': relative.as_posix(), 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()})
    # Retain device-specific setup, native binaries and add-ons absent from the build.
    for addon in (home / 'addons').iterdir():
        if addon.is_symlink():
            raise ValueError('Linked add-on requires manual recovery')
        destination = payload / 'addons' / addon.name
        if addon.is_dir() and (not destination.exists() or addon.name == 'service.jvbuilt.device_setup'):
            copy_tree(addon, destination)
    wizard = Path('addons/plugin.program.jvbuiltwizard')
    if (home / wizard / 'addon.xml').exists():
        old_version = tuple(int(v) for v in ET.parse(home / wizard / 'addon.xml').getroot().get('version').split('.'))
        new_version = tuple(int(v) for v in ET.parse(payload / wizard / 'addon.xml').getroot().get('version').split('.'))
        if old_version > new_version:
            copy_tree(home / wizard, payload / wizard)
    # Personal pin implementation accompanies the saved widget pin data.
    pin = Path('addons/plugin.video.themoviedb.helper/resources/tmdbhelper/lib/items/directories/lists_default.py')
    if (userdata / 'jvbuilt_widget_pins.json').exists() and (home / pin).is_file():
        copy_file(home / pin, payload / pin)
    # Preserve each installed add-on's state without importing a stale build registry.
    old = sorted((userdata / 'Database').glob('Addons*.db'))
    new = sorted((payload / 'userdata/Database').glob('Addons*.db'))
    if old and new:
        with closing(sqlite3.connect(str(old[-1]))) as src, closing(sqlite3.connect(str(new[-1]))) as dst:
            columns = [r[1] for r in dst.execute('PRAGMA table_info(installed)')]
            for row in src.execute('SELECT ' + ','.join(columns) + ' FROM installed'):
                aid = row[columns.index('addonID')]
                if (payload / 'addons' / aid).is_dir():
                    dst.execute('INSERT OR REPLACE INTO installed (' + ','.join(columns) + ') VALUES (' + ','.join('?' for _ in columns) + ')', row)
            dst.commit()
    for item in protected:
        if hashlib.sha256((payload / 'userdata' / item['path']).read_bytes()).hexdigest() != item['sha256']:
            raise ValueError('Preserved data verification failed')
    identity = userdata / 'jvbuilt_device.json'
    if identity.exists() and identity.read_bytes() != (payload / 'userdata/jvbuilt_device.json').read_bytes():
        raise ValueError('Device identity verification failed')
    report = {'same_device_only': True, 'verified_files': len(protected), 'files': protected, 'recovery_directory': str(recovery / 'previous-home')}
    (recovery / 'preservation.json').write_text(json.dumps(report, indent=2))
    return report


def activate(home, payload, recovery):
    home, payload, recovery = map(Path, (home, payload, recovery))
    previous = recovery / 'previous-home'
    if previous.exists():
        raise ValueError('Recovery folder already exists')
    home.rename(previous)
    try:
        payload.rename(home)
    except BaseException:
        previous.rename(home)
        raise
