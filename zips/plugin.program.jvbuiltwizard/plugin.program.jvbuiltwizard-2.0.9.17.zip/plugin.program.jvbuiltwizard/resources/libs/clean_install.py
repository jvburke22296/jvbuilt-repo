"""Verified full reset for Fire TV/Android and Windows Kodi."""
def run(name):
    import os,sys,shutil,subprocess,json,tempfile
    from pathlib import Path
    from urllib.request import Request,urlopen
    import xbmc,xbmcgui,xbmcvfs
    from resources.libs.common.config import CONFIG
    from resources.libs import check,clean_install_worker as worker
    dialog=xbmcgui.Dialog();progress=None;folder=None;launched=False
    build_version=str(check.check_build(name,'version') or '6.4.3')
    try:
        home=Path(CONFIG.HOME).resolve()
        android=xbmc.getCondVisibility('System.Platform.Android')
        python=None;kodi=None
        if android:
            from resources.libs import android_clean
            home=android_clean.validate_home(CONFIG.HOME)
        else:
            python=shutil.which('python')
            if not sys.platform.startswith('win') or not python or home!=(Path(os.environ.get('APPDATA',''))/'Kodi').resolve():
                raise ValueError('Supported: standard Kodi data folder on Fire TV/Android, or Windows with Python 3.8+. Nothing was removed.')
            kodi=Path(xbmcvfs.translatePath('special://xbmc/'))/'kodi.exe'
            if not kodi.is_file():raise ValueError('Kodi executable not found')
            subprocess.run([python,'-c','import sys; assert sys.version_info >= (3,8)'],check=True,creationflags=0x08000000,timeout=15)
        if not dialog.yesno('JVBuilt '+build_version+' â€” DEVICE UPDATE','Install the verified build and preserve this device’s accounts, settings, sources, libraries, profiles, favourites and backup schedule. The previous Kodi folder is retained outside the active profile for recovery. Allow enough storage for both copies. Continue?',nolabel='Cancel',yeslabel='Update and preserve'):return
        folder=Path(tempfile.mkdtemp(prefix='.jvbuilt-clean-',dir=str(home.parent))) if android else Path(tempfile.mkdtemp(prefix='JVBuilt-clean-'))
        package=folder/'build.zip';url=check.check_build(name,'url')
        if not url:raise ValueError('Build download was not found in the feed')
        progress=xbmcgui.DialogProgress();progress.create('JVBuilt '+build_version,'Downloading and verifying before any data is removedâ€¦')
        with urlopen(url+'.sha256',timeout=30) as response:digest=response.read().decode().strip()
        with urlopen(Request(url,headers={'X-JVBuilt-Clean-Installer':'1'}),timeout=60) as response,package.open('wb') as output:
            total=int(response.headers.get('Content-Length','0'));count=0
            if total and shutil.disk_usage(folder).free<total+64*1024*1024:raise ValueError('Not enough storage to download the build')
            while True:
                chunk=response.read(1024*1024)
                if not chunk:break
                output.write(chunk);count+=len(chunk)
                progress.update(int(count*100/total) if total else 0)
                if progress.iscanceled():return
        worker.validate_archive(package,digest)
        if android:
            script=android_clean.prepare(home,folder,package,progress)
            progress.close()
            dialog.ok('Device update is ready','Your device data has been staged and verified. Press OK to activate the prepared update. Kodi will close when finished. Then reopen Kodi from the Fire TV home screen. Please do not interrupt the reset.')
            launched=True
            android_clean.handoff(script,folder)
        else:
            from resources.libs import preserve_device
            shutil.copy2(preserve_device.__file__,folder/'preserve_device.py')
            shutil.copy2(worker.__file__,folder/'worker.py');job=folder/'job.json'
            job.write_text(json.dumps({'home':str(home),'package':str(package),'sha256':digest,'kodi':str(kodi)}))
            subprocess.Popen([python,str(folder/'worker.py'),str(job)],creationflags=0x08000000);launched=True
            progress.close();dialog.ok('JVBuilt '+build_version,'Download verified. Kodi will close, preserve its data, install the build and reopen. Please wait. Installer log folder: '+str(folder))
            xbmc.executebuiltin('Quit()')
    except Exception as exc:
        dialog.ok('Clean installation stopped',str(exc)+(' The reset did not finish. Prepared files remain at '+str(folder) if launched else ' Your existing Kodi data has not been purged.'))
    finally:
        if progress:progress.close()
        if folder and not launched:shutil.rmtree(folder,ignore_errors=True)
