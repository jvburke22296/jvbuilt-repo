"""Select English at each VOD start, without blocking or opening a subtitle dialog."""
import json
import time
import re
import os
import shutil
import xbmc
import xbmcgui


def english(track):
    language = str(track.get('language', '')).lower().strip()
    if language in ('en', 'eng', 'english') or language.startswith(('en-', 'en_')):
        return True
    return language in ('', 'und', 'unknown') and bool(re.search(r'\b(english|eng|en)\b', track.get('name', ''), re.I))


def choose(tracks):
    matches = [t for t in tracks if english(t)]
    # Prefer full dialogue to a forced-only track.
    matches.sort(key=lambda t: ('forced' in t.get('name', '').lower(), t['index']))
    return matches[0]['index'] if matches else None


def rpc(method, params=None):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps(dict(jsonrpc='2.0', id=1, method=method, params=params or {}))))
    if 'error' in reply:
        raise RuntimeError(reply['error']['message'])
    return reply.get('result')


class Player(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.deadline = 0
        self.selected = False

    def onPlayBackStarted(self):
        self.deadline = time.monotonic() + 30
        self.selected = False

    def onAVStarted(self):
        self.onPlayBackStarted()

    def onPlayBackStopped(self):
        self.deadline = 0

    onPlayBackEnded = onPlayBackStopped
    onPlayBackError = onPlayBackStopped


def main():
    window = xbmcgui.Window(10000)
    key = 'JVBuilt.EnglishSubtitles.Running'
    if window.getProperty(key):
        return
    window.setProperty(key, 'true')
    monitor = xbmc.Monitor()
    player = Player()
    next_export = 0
    try:
        rpc('Settings.SetSettingValue', {'setting': 'locale.subtitlelanguage', 'value': 'English'})
        while not monitor.waitForAbort(.25):
            if time.monotonic() >= next_export:
                next_export = time.monotonic() + 900
                try:
                    if xbmc.getCondVisibility('System.Platform.Android'):
                        import xbmcvfs
                        destination = '/storage/emulated/0/Download/JVBuiltLogExport'
                        os.makedirs(destination, exist_ok=True)
                        for name in ('kodi.log', 'kodi.old.log'):
                            source = xbmcvfs.translatePath('special://logpath/' + name)
                            if os.path.isfile(source):
                                shutil.copyfile(source, os.path.join(destination, name))
                        with open(os.path.join(destination, 'export.json'), 'w') as stream:
                            json.dump({'exported_at': time.time()}, stream)
                except Exception as exc:
                    xbmc.log('JVBuilt log export: ' + str(exc), xbmc.LOGDEBUG)
            if not player.deadline or player.selected:
                continue
            if time.monotonic() > player.deadline:
                player.deadline = 0
                continue
            try:
                active = next((p for p in rpc('Player.GetActivePlayers') if p['type'] == 'video'), None)
                if not active:
                    continue
                pid = active['playerid']
                item = rpc('Player.GetItem', {'playerid': pid, 'properties': ['file']})['item']
                if item.get('file', '').startswith('pvr://') or xbmc.getCondVisibility('PVR.IsPlayingTV'):
                    player.deadline = 0
                    continue
                props = rpc('Player.GetProperties', {'playerid': pid, 'properties': ['subtitles', 'totaltime']})
                if item.get('type') not in ('movie', 'episode') and not any(props['totaltime'].values()):
                    continue
                index = choose(props['subtitles'])
                rpc('Player.SetSubtitle', {'playerid': pid, 'subtitle': index if index is not None else 'off', 'enable': index is not None})
                if index is not None:
                    player.selected = True
                    xbmc.log('JVBuilt: English subtitles enabled for this playback', xbmc.LOGINFO)
            except Exception as exc:
                xbmc.log('JVBuilt subtitle startup retry: ' + str(exc), xbmc.LOGDEBUG)
    finally:
        window.clearProperty(key)


if __name__ == '__main__':
    main()
