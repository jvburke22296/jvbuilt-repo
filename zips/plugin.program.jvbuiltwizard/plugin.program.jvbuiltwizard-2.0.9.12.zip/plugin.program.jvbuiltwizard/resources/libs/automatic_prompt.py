"""Confirm only the requested official playback add-on's install prompt."""
import re
import sqlite3
from contextlib import closing
from pathlib import Path

ALLOWED = {'inputstream.adaptive', 'inputstream.ffmpegdirect', 'inputstream.rtmp',
           'pvr.iptvsimple', 'vfs.libarchive'}


def official_name(addon):
    if addon not in ALLOWED:
        return None
    from resources.libs.common.config import CONFIG
    databases = sorted(Path(CONFIG.DATABASE).glob('Addons*.db'), key=lambda p: int(p.stem[6:]))
    if not databases:
        return None
    with closing(sqlite3.connect(str(databases[-1]), timeout=5)) as conn:
        row = conn.execute('SELECT a.name FROM addons a JOIN addonlinkrepo l ON l.idAddon=a.id '
                           'JOIN repo r ON r.id=l.idRepo WHERE r.addonID=? AND a.addonID=? LIMIT 1',
                           ('repository.xbmc.org', addon)).fetchone()
    return row[0] if row else None


def plain(value):
    return ' '.join(re.sub(r'\[[^\]]*\]', '', value or '').casefold().split())


def approve(name):
    import xbmc, xbmcgui
    if not name or xbmcgui.getCurrentWindowDialogId() != 10100:
        return False
    try:
        window = xbmcgui.Window(10100)
        heading = plain(window.getControl(1).getLabel())
        body = plain(window.getControl(9).getText())
        required = [plain(xbmc.getLocalizedString(i)) for i in (24100, 24101)]
        if heading != plain(xbmc.getLocalizedString(24076)):
            return False
        if not all(required) or not all(text in body for text in required + [plain(name)]):
            return False
        xbmc.executebuiltin('SendClick(10100,11)')
        return True
    except (RuntimeError, AttributeError):
        return False
