def run():
    import os,xml.etree.ElementTree as E
    import xbmc,xbmcaddon
    from resources.libs.common.config import CONFIG
    from resources.libs.common import logging
    try:
        addon=xbmcaddon.Addon('script.skinshortcuts')
        changed=addon.getSetting('donthidepvr')!='true'
        if changed:addon.setSetting('donthidepvr','true')
        path=os.path.join(CONFIG.USERDATA,'addon_data','script.skinshortcuts','mainmenu.DATA.xml')
        if os.path.exists(path):
            r=E.parse(path).getroot();modified=False
            for x in r:
                a=x.find('action')
                if a is not None and (a.text or '').lower()=='activatewindow(tvchannels)':
                    a.text='RunPlugin(plugin://plugin.program.jvbuiltwizard/?mode=livetv)';modified=True
            if modified:E.ElementTree(r).write(path,encoding='utf-8',xml_declaration=True);changed=True
        if changed:
            h=os.path.join(CONFIG.USERDATA,'addon_data','script.skinshortcuts',xbmc.getSkinDir()+'.hash')
            if os.path.exists(h):os.remove(h)
            xbmc.executebuiltin('ReloadSkin()')
    except Exception as exc:logging.log('Live TV menu repair: '+str(exc),level=xbmc.LOGWARNING)
