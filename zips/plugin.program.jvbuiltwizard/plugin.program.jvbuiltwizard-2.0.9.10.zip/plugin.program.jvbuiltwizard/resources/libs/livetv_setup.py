"""Finish platform-specific IPTV setup without hiding the Live TV home item."""
def open_live_tv():
    import json
    import xbmc,xbmcgui
    from resources.libs.native_addons import install_enabled,refresh_official_catalog
    if not xbmc.getCondVisibility('System.AddonIsEnabled(pvr.iptvsimple)') and not refresh_official_catalog():
        xbmcgui.Dialog().ok('Live TV setup','Kodi could not refresh its official PVR add-on catalog. Check the internet connection, then select Live TV to retry.')
        return
    if not install_enabled('pvr.iptvsimple'):
        xbmcgui.Dialog().ok('Live TV setup','IPTV Simple Client did not finish installing or could not be enabled. Install it from Kodi Add-ons > PVR clients, then select Live TV again.')
        return
    monitor=xbmc.Monitor()
    progress=xbmcgui.DialogProgress();progress.create('Live TV','Loading channels from IPTV Simple Client…')
    for count in range(30):
        if xbmc.getCondVisibility('PVR.HasTVChannels'):break
        if progress.iscanceled() or monitor.waitForAbort(1):break
        progress.update(int((count+1)*100/30))
    progress.close()
    if not xbmc.getCondVisibility('PVR.HasTVChannels'):
        xbmcgui.Dialog().notification('Live TV','IPTV client is enabled. Channel loading may take a minute; check its playlist settings if channels stay empty.')
    xbmc.executebuiltin('ActivateWindow(TVChannels)')
