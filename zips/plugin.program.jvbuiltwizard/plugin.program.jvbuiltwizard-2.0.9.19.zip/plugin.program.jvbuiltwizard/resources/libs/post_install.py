"""Finish the published build's allowlisted add-on setup on first startup."""
import json
from pathlib import Path


def enabled(addon):
    import xbmc
    response = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1,
        'method': 'Addons.GetAddonDetails', 'params': {'addonid': addon, 'properties': ['enabled']}})))
    return response.get('result', {}).get('addon', {}).get('enabled', False)


def run():
    import xbmc, xbmcgui
    from resources.libs.common.config import CONFIG
    from resources.libs import restore
    marker = Path(CONFIG.USERDATA) / 'jvbuilt_setup.json'
    if not marker.exists():
        return True
    state = json.loads(marker.read_text(encoding='utf-8'))
    monitor = xbmc.Monitor()
    xbmcgui.Dialog().notification("JVBuilt's Garage", 'Finishing add-on setup automatically', time=5000)
    xbmc.executebuiltin('UpdateLocalAddons')
    if monitor.waitForAbort(2):
        return False
    pending = list(state['addons'])
    # Dependencies may become available as their own dependencies are enabled.
    for attempt in range(3):
        for addon in pending[:]:
            if not (Path(CONFIG.ADDONS) / addon / 'addon.xml').is_file():
                continue
            if not enabled(addon):
                xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1,
                    'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon, 'enabled': True}}))
            if enabled(addon):
                pending.remove(addon)
        if not pending:
            break
        if monitor.waitForAbort(2):
            return False
    binaries_ok = restore.binaries()
    if binaries_ok and pending:
        for addon in pending[:]:
            if not (Path(CONFIG.ADDONS) / addon / 'addon.xml').is_file():
                continue
            xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1,
                'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon, 'enabled': True}}))
            if enabled(addon):
                pending.remove(addon)
    if pending or not binaries_ok:
        # Keep the original allowlist so interrupted setup remains retryable.
        state['pending'] = pending
        marker.write_text(json.dumps(state), encoding='utf-8')
        xbmcgui.Dialog().notification("JVBuilt's Garage", 'Setup incomplete; remaining add-ons will retry next start', time=7000)
        return False
    marker.unlink()
    CONFIG.set_setting('enable_all', 'false')
    xbmcgui.Dialog().notification("JVBuilt's Garage", 'Add-on setup complete', time=5000)
    xbmc.executebuiltin('ReloadSkin()')
    return True
