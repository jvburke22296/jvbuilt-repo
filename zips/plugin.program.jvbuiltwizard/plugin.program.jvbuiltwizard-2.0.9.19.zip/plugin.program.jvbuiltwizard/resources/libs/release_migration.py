"""Dispatch the release-specific, staged-only migration."""
from pathlib import Path
import importlib.util
import json

def _module(payload, version):
    name = 'current_setup_migration' if version == '6.4.14' else 'sports_migration'
    path = Path(payload) / ('addons/plugin.program.jvbuiltwizard/resources/libs/' + name + '.py')
    spec = importlib.util.spec_from_file_location('jvbuilt_' + name, str(path))
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

def prepare(payload):
    version = json.loads((Path(payload)/'userdata/jvbuilt_setup.json').read_text()).get('version')
    plan = _module(payload, version).prepare(payload)
    return {'version': version, 'plan': plan}

def apply(home, payload, recovery, plan):
    if plan is None: return {'applied': False, 'changed_files': []}
    return _module(payload, plan['version']).apply(home, payload, recovery, plan['plan'])
