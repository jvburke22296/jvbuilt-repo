"""Select English at each VOD start, without blocking or opening a subtitle dialog."""
import json
import time
import re
import os
import shutil
import threading
import xbmc


def english(track):
    language = str(track.get('language', '')).lower().strip()
    if language in ('en', 'eng', 'english') or language.startswith(('en-', 'en_')):
        return True
    return language in ('', 'und', 'unknown') and bool(re.search(r'\b(english|eng|en)\b', track.get('name', ''), re.I))


def choose(tracks):
    matches = [t for t in tracks if english(t)]
    # Prefer full dialogue to a forced-only track.
    matches.sort(key=lambda t: ('forced' in t.get('name', '').lower(), t['index']))
    return matches[0]['index'] if matches else None


def rpc(method, params=None):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps(dict(jsonrpc='2.0', id=1, method=method, params=params or {}))))
    if 'error' in reply:
        raise RuntimeError(reply['error']['message'])
    return reply.get('result')


class Player(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.deadline = 0
        self.selected = False

    def onPlayBackStarted(self):
        self.deadline = time.monotonic() + 30
        self.selected = False

    def onAVStarted(self):
        self.onPlayBackStarted()

    def onPlayBackStopped(self):
        self.deadline = 0

    onPlayBackEnded = onPlayBackStopped
    onPlayBackError = onPlayBackStopped


def main(monitor=None, stop_event=None):
    monitor = monitor if monitor is not None else xbmc.Monitor()
    stop_event = stop_event if stop_event is not None else threading.Event()

    def stopping():
        return stop_event.is_set() or monitor.abortRequested()

    player = Player()
    next_export = 0
    try:
        if stopping():
            return
        rpc('Settings.SetSettingValue', {'setting': 'locale.subtitlelanguage', 'value': 'English'})
        # Startup may finish while a video is already playing. Catch that video
        # as well as subsequent Player callbacks.
        if not stopping() and player.isPlayingVideo():
            player.onPlayBackStarted()
        xbmc.log('JVBuilt subtitle service started', xbmc.LOGINFO)
        while not stopping() and not monitor.waitForAbort(.25):
            if stopping():
                break
            if time.monotonic() >= next_export:
                next_export = time.monotonic() + 900
                try:
                    if xbmc.getCondVisibility('System.Platform.Android'):
                        import xbmcvfs
                        destination = '/storage/emulated/0/Download/JVBuiltLogExport'
                        os.makedirs(destination, exist_ok=True)
                        for name in ('kodi.log', 'kodi.old.log'):
                            source = xbmcvfs.translatePath('special://logpath/' + name)
                            if os.path.isfile(source):
                                shutil.copyfile(source, os.path.join(destination, name))
                        with open(os.path.join(destination, 'export.json'), 'w') as stream:
                            json.dump({'exported_at': time.time()}, stream)
                except Exception as exc:
                    xbmc.log('JVBuilt log export: ' + str(exc), xbmc.LOGDEBUG)
            if stopping():
                break
            if not player.deadline or player.selected:
                continue
            if time.monotonic() > player.deadline:
                player.deadline = 0
                continue
            try:
                active = next((p for p in rpc('Player.GetActivePlayers') if p['type'] == 'video'), None)
                if not active:
                    continue
                if stopping():
                    break
                pid = active['playerid']
                item = rpc('Player.GetItem', {'playerid': pid, 'properties': ['file']})['item']
                if item.get('file', '').startswith('pvr://') or xbmc.getCondVisibility('PVR.IsPlayingTV'):
                    player.deadline = 0
                    continue
                props = rpc('Player.GetProperties', {'playerid': pid, 'properties': ['subtitles', 'totaltime']})
                if item.get('type') not in ('movie', 'episode') and not any(props['totaltime'].values()):
                    continue
                index = choose(props['subtitles'])
                if stopping():
                    break
                rpc('Player.SetSubtitle', {'playerid': pid, 'subtitle': index if index is not None else 'off', 'enable': index is not None})
                if index is not None:
                    player.selected = True
                    xbmc.log('JVBuilt: English subtitles enabled for this playback', xbmc.LOGINFO)
            except Exception as exc:
                xbmc.log('JVBuilt subtitle startup retry: ' + str(exc), xbmc.LOGDEBUG)
    finally:
        # Never touch xbmcgui.Window here: its property/destructor methods
        # acquire Kodi's graphics lock while the GUI is being torn down.
        xbmc.log('JVBuilt subtitle service stopped', xbmc.LOGINFO)


class Service:
    """Keep subtitle monitoring owned by the wizard's registered service.

    A path-based RunScript is a separate invoker that outlives startup.py.
    Sharing the service-owned Monitor makes disable/logout/shutdown abort the
    subtitle worker along with its owner, rather than leaving an orphan script.
    """

    def __init__(self):
        self.monitor = xbmc.Monitor()
        self.stop_event = threading.Event()
        self.thread = None

    def start(self):
        if self.thread is not None and self.thread.is_alive():
            return
        self.thread = threading.Thread(
            target=main, kwargs={'monitor': self.monitor, 'stop_event': self.stop_event},
            name='JVBuilt English subtitles', daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        if self.thread is not None and self.thread is not threading.current_thread():
            self.thread.join(2)

    def wait(self):
        try:
            while self.thread is not None and self.thread.is_alive():
                if self.monitor.waitForAbort(.5):
                    break
        finally:
            self.stop()


if __name__ == '__main__':
    main()
