"""Refresh target-device candidates and verify native add-ons are enabled."""
def refresh_official_catalog():
    import sqlite3,time
    from contextlib import closing
    from pathlib import Path
    import xbmc
    from resources.libs.common.config import CONFIG
    dbs=sorted(Path(CONFIG.DATABASE).glob('Addons*.db'),key=lambda p:int(p.stem[6:]))
    if not dbs:return False
    path=str(dbs[-1]);repo='repository.xbmc.org'
    try:
        with closing(sqlite3.connect(path,timeout=15)) as c:
            ids=[r[0] for r in c.execute('SELECT id FROM repo WHERE addonID=?',(repo,))]
            for rid in ids:c.execute('DELETE FROM addonlinkrepo WHERE idRepo=?',(rid,))
            c.execute('DELETE FROM addons WHERE id NOT IN (SELECT idAddon FROM addonlinkrepo)')
            c.execute("UPDATE repo SET checksum='',lastcheck='',nextcheck='' WHERE addonID=?",(repo,))
            c.commit()
    except sqlite3.Error:return False
    xbmc.executebuiltin('UpdateAddonRepos')
    monitor=xbmc.Monitor();start=time.monotonic()
    while time.monotonic()-start<180:
        try:
            with closing(sqlite3.connect(path,timeout=5)) as c:
                row=c.execute('SELECT lastcheck FROM repo WHERE addonID=?',(repo,)).fetchone()
                found=c.execute("SELECT 1 FROM addons a JOIN addonlinkrepo l ON l.idAddon=a.id JOIN repo r ON r.id=l.idRepo WHERE r.addonID=? AND a.addonID='pvr.iptvsimple' LIMIT 1",(repo,)).fetchone()
            if found:return True
        except sqlite3.Error:pass
        if monitor.waitForAbort(1):return False
    return False

def install_enabled(addon, automatic=False):
    import json,time
    import xbmc
    exists='System.HasAddon({})'.format(addon);enabled='System.AddonIsEnabled({})'.format(addon)
    if xbmc.getCondVisibility(enabled):return True
    from resources.libs.automatic_prompt import official_name, approve
    expected_name = official_name(addon) if automatic else None
    if not xbmc.getCondVisibility(exists):xbmc.executebuiltin('InstallAddon({})'.format(addon))
    monitor=xbmc.Monitor();start=time.monotonic();last_enable=-10
    while time.monotonic()-start<180:
        if expected_name:approve(expected_name)
        if xbmc.getCondVisibility(exists) and time.monotonic()-last_enable>3:
            xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Addons.SetAddonEnabled','params':{'addonid':addon,'enabled':True}}));last_enable=time.monotonic()
        if xbmc.getCondVisibility(enabled):return True
        if monitor.waitForAbort(.5):return False
    return False
