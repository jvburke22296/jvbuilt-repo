"""Pure staged-payload migration for the single shared Detroit Sports release."""
from pathlib import Path
import copy
import hashlib
import json
import xml.etree.ElementTree as ET

MIGRATION_ID = 'detroit-sports-v1'
MARKER = Path('userdata/jvbuilt_release_migrations.json')
SHORTCUTS = Path('userdata/addon_data/script.skinshortcuts')
PROPERTIES = SHORTCUTS / 'skin.arctic.zephyr.mod.properties'
MAIN = SHORTCUTS / 'mainmenu.DATA.xml'
SUBMENUS = ('sports.DATA.xml', 'plugin-video-madtitansports-jvbuilt-sports.DATA.xml')


def _json(path, default):
    return json.loads(path.read_text(encoding='utf-8-sig')) if path.exists() else default


def _sports(node):
    ident = (node.findtext('defaultID') or '').lower()
    label = (node.findtext('label') or '').lower()
    action = (node.findtext('action') or '').lower()
    return ident == 'sports' or label == 'sports' or 'plugin://plugin.video.madtitansports/jvbuilt_sports' in action


def _digest(data):
    return hashlib.sha256(data).hexdigest() if data is not None else None


def prepare(payload):
    """Snapshot only the incoming release's controlled Sports fields before merge."""
    payload = Path(payload)
    setup = _json(payload / 'userdata/jvbuilt_setup.json', {})
    if setup.get('distribution') != 'universal' or setup.get('version') != '6.4.13':
        return None
    root = ET.parse(payload / MAIN).getroot()
    canonical = next((node for node in root if _sports(node)), None)
    if canonical is None:
        raise ValueError('Universal build is missing its canonical Sports menu')
    action = canonical.findtext('action') or ''
    if 'plugin://plugin.video.madtitansports/jvbuilt_sports' not in action:
        raise ValueError('Universal Sports menu must use the scoreboard destination')
    rows = _json(payload / PROPERTIES, [])
    if not isinstance(rows, list):
        raise ValueError('Universal Sports properties must be a list')
    keys = [row[1] for row in rows if isinstance(row, list) and len(row) >= 4 and row[2] == 'widgetPath' and 'plugin://plugin.video.madtitansports/jvbuilt_sports' in str(row[3])]
    if len(set(keys)) != 1:
        raise ValueError('Universal build must have one canonical Sports widget key')
    key = keys[0]
    selected = [copy.deepcopy(row) for row in rows if isinstance(row, list) and len(row) >= 4 and row[0] == 'mainmenu' and row[1] == key]
    needed = {row[2] for row in selected}
    if not {'background', 'backgroundName', 'widget', 'widgetName', 'widgetPath', 'widgetTarget', 'widgetType'}.issubset(needed):
        raise ValueError('Universal Sports widget configuration is incomplete')
    return {'version': setup['version'], 'shortcut': ET.tostring(canonical), 'key': key, 'rows': selected,
            'submenus': {name: (payload / SHORTCUTS / name).read_bytes() for name in SUBMENUS}}


def apply(home, payload, recovery, plan):
    if plan is None:
        return {'applied': False, 'reason': 'not_this_release', 'changed_files': []}
    home, payload, recovery = map(Path, (home, payload, recovery))
    previous = _json(home / MARKER, {})
    applied = previous.get('applied', [])
    if not isinstance(applied, list) or not all(isinstance(item, str) for item in applied):
        raise ValueError('Existing release migration marker is invalid')
    if MIGRATION_ID in applied:
        return {'id': MIGRATION_ID, 'applied': False, 'reason': 'already_applied', 'changed_files': []}
    changes = []

    def put(relative, data):
        target = payload / relative
        before = target.read_bytes() if target.exists() else None
        if before == data:
            return
        if data is None:
            target.unlink()
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        changes.append({'path': relative.as_posix(), 'before_sha256': _digest(before), 'after_sha256': _digest(data)})

    path = payload / MAIN
    root = ET.parse(path).getroot() if path.exists() else ET.Element('shortcuts')
    matched = [node for node in root if _sports(node)]
    original_non_sports = [ET.tostring(node) for node in root if node not in matched]
    aliases = {'sports', plan['key'], 'plugin-video-madtitansports-jvbuilt-sports'}
    for node in matched:
        default = node.findtext('defaultID') or ''
        if default:
            aliases.add(default)
    replacement = ET.fromstring(plan['shortcut'])
    if matched:
        index = list(root).index(matched[0])
        for duplicate in matched:
            root.remove(duplicate)
        root.insert(index, replacement)
    else:
        index = next((i for i, node in enumerate(root) if (node.findtext('defaultID') or '').lower() == 'settings'), len(root))
        root.insert(index, replacement)
    if [ET.tostring(node) for node in root if node is not replacement and node not in matched] != original_non_sports:
        raise ValueError('Migration would alter unrelated main menu entries')
    put(MAIN, ET.tostring(root, encoding='utf-8', xml_declaration=True))

    rows = _json(payload / PROPERTIES, [])
    if not isinstance(rows, list):
        raise ValueError('Existing shortcut properties must be a list')
    unrelated = [row for row in rows if not (isinstance(row, list) and len(row) >= 4 and row[0] == 'mainmenu' and row[1] in aliases)]
    merged = unrelated + copy.deepcopy(plan['rows'])
    if merged[:len(unrelated)] != unrelated:
        raise ValueError('Migration would alter unrelated widget properties')
    put(PROPERTIES, json.dumps(merged, indent=2).encode('utf-8'))
    for name, data in plan['submenus'].items():
        ET.fromstring(data)
        put(SHORTCUTS / name, data)
    cached = SHORTCUTS / 'skin.arctic.zephyr.mod.hash'
    if (payload / cached).exists():
        put(cached, None)
    state = copy.deepcopy(previous)
    state['applied'] = applied + [MIGRATION_ID]
    put(MARKER, json.dumps(state, indent=2).encode('utf-8'))
    receipt = {'id': MIGRATION_ID, 'version': plan['version'], 'applied': True, 'changed_files': changes,
               'unrelated_menu_entries': len(original_non_sports), 'unrelated_widget_rows': len(unrelated),
               'unrelated_menu_sha256': _digest(b''.join(original_non_sports)),
               'unrelated_widgets_sha256': _digest(json.dumps(unrelated, separators=(',', ':')).encode('utf-8'))}
    (recovery / 'sports-migration.json').write_bytes(json.dumps(receipt, indent=2).encode('utf-8'))
    return receipt
