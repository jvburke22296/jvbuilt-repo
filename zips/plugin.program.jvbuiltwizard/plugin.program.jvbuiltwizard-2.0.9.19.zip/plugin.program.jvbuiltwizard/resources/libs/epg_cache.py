"""Keep IPTV Simple on the last complete guide, not a partial network response.

Enabled only by epg-cache/active.json. Downloads and validation happen beside
the live file; a failed or aborted refresh never replaces the last good guide.
"""
import json
import os
import pathlib
import subprocess
import sys
import threading
import time
import urllib.parse
import xml.etree.ElementTree as ET

import requests
import xbmc
import xbmcvfs


MAX_BYTES = 100 * 1024 * 1024


class Aborted(Exception):
    pass


def validate_xml(path, stopping=lambda: False):
    """Parse through EOF while keeping memory bounded on a multi-MB XMLTV file."""
    counts = {'channels': 0, 'programmes': 0}
    root = None
    for event, element in ET.iterparse(str(path), events=('start', 'end')):
        if stopping():
            raise Aborted('Guide validation aborted')
        if root is None:
            root = element
            if element.tag != 'tv':
                raise ValueError('Guide root must be XMLTV tv')
        if event == 'end':
            if element.tag == 'channel':
                counts['channels'] += 1
            elif element.tag == 'programme':
                counts['programmes'] += 1
            element.clear()
            if element is not root:
                root.clear()
    if not counts['channels'] or not counts['programmes']:
        raise ValueError('Guide must contain channels and programmes')
    return counts


def configuration(path):
    if not path.is_file():
        return None
    data = json.loads(path.read_text(encoding='utf-8'))
    if data.get('enabled') is not True:
        return None
    url = data.get('url', '')
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != 'https' or not parsed.netloc or parsed.username or parsed.password:
        raise ValueError('Guide URL must be HTTPS without embedded credentials')
    return {
        'url': url,
        'refresh_seconds': max(300, min(86400, int(data.get('refresh_seconds', 10800)))),
        'retry_seconds': max(60, min(10800, int(data.get('retry_seconds', 1800)))),
        'max_bytes': max(1024, min(MAX_BYTES, int(data.get('max_bytes', MAX_BYTES)))),
    }


class Service:
    def __init__(self, monitor, cache_dir=None, get=None, clock=None):
        self.monitor = monitor
        self.stop_event = threading.Event()
        self.cache_dir = pathlib.Path(cache_dir or xbmcvfs.translatePath(
            'special://profile/addon_data/plugin.program.jvbuiltwizard/epg-cache'))
        self.get = get or requests.get
        self.clock = clock or time.time
        self.thread = None
        self._next_attempt = 0
        self._configuration_key = None
        self._existing_checked = False

    def stopping(self):
        return self.stop_event.is_set() or self.monitor.abortRequested()

    def _status(self, value):
        try:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            part = self.cache_dir / 'status.json.part'
            part.write_text(json.dumps(value, indent=2), encoding='utf-8')
            os.replace(str(part), str(self.cache_dir / 'status.json'))
        except OSError as exc:
            xbmc.log('JVBuilt EPG status save failed: ' + str(exc), xbmc.LOGWARNING)

    def refresh(self, cfg):
        if self.stopping():
            raise Aborted('Guide refresh aborted')
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        part = self.cache_dir / ('guide.xml.part-' + str(os.getpid()) + '-' + str(threading.get_ident()))
        try:
            method = 'requests'
            try:
                total = self._download_requests(cfg, part)
            except (requests.exceptions.ConnectionError, requests.exceptions.Timeout,
                    requests.exceptions.ChunkedEncodingError) as exc:
                curl = self._windows_curl()
                if curl is None or self.stopping():
                    raise
                xbmc.log('JVBuilt EPG transport failed; retrying with Windows TLS: ' + str(exc), xbmc.LOGWARNING)
                total = self._download_windows(cfg, part, curl)
                method = 'windows_curl'
            counts = validate_xml(part, self.stopping)
            if self.stopping():
                raise Aborted('Guide publish aborted')
            os.replace(str(part), str(self.cache_dir / 'guide.xml'))
            value = {'state': 'ready', 'url': cfg['url'], 'last_success': self.clock(),
                     'bytes': total, 'download_method': method, **counts}
            self._status(value)
            xbmc.log('JVBuilt EPG cache ready: {channels} channels, {programmes} programmes, {bytes} bytes'.format(**value), xbmc.LOGINFO)
            return value
        finally:
            # Only our named partial file is removed; guide.xml is never removed.
            try:
                part.unlink()
            except FileNotFoundError:
                pass

    def _download_requests(self, cfg, part):
        total = 0
        started = time.monotonic()
        # No ranges or redirects. Each response must stand alone and validate.
        with self.get(cfg['url'], stream=True, timeout=(2, 2), allow_redirects=False,
                      headers={'Accept-Encoding': 'identity', 'Cache-Control': 'no-cache'}) as response:
            if response.status_code != 200:
                raise ValueError('Guide HTTP status ' + str(response.status_code))
            length = response.headers.get('Content-Length')
            if length is not None and int(length) > cfg['max_bytes']:
                raise ValueError('Guide exceeds configured size limit')
            with part.open('wb') as stream:
                for block in response.iter_content(chunk_size=65536):
                    if self.stopping():
                        raise Aborted('Guide download aborted')
                    if time.monotonic() - started > 120:
                        raise ValueError('Guide download exceeded total time limit')
                    if not block:
                        continue
                    total += len(block)
                    if total > cfg['max_bytes']:
                        raise ValueError('Guide exceeds configured size limit')
                    stream.write(block)
            if length is not None and not response.headers.get('Content-Encoding') and total != int(length):
                raise ValueError('Incomplete guide response')
        return total

    @staticmethod
    def _windows_curl():
        if sys.platform != 'win32':
            return None
        system_root = os.environ.get('SystemRoot')
        if not system_root:
            return None
        executable = pathlib.Path(system_root) / 'System32' / 'curl.exe'
        return executable if executable.is_absolute() and executable.is_file() else None

    @staticmethod
    def _terminate(process):
        """Terminate and reap the child rather than leave network work behind."""
        if process.poll() is None:
            process.terminate()
        try:
            return process.communicate(timeout=1)
        except subprocess.TimeoutExpired:
            process.kill()
            return process.communicate(timeout=1)

    def _download_windows(self, cfg, part, executable):
        if self.stopping():
            raise Aborted('Guide native download aborted')
        # Absolute Windows system executable only: never resolve curl via PATH.
        # Native curl uses Schannel, keeping normal certificate verification.
        argv = [str(executable), '--disable', '--silent', '--show-error', '--fail',
                '--proto', '=https', '--connect-timeout', '2', '--max-time', '30',
                '--max-filesize', str(cfg['max_bytes']), '--output', str(part),
                '--write-out', '%{http_code}', '--url', cfg['url']]
        process = subprocess.Popen(argv, shell=False, stdin=subprocess.DEVNULL,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        deadline = time.monotonic() + 32
        try:
            while process.poll() is None:
                if self.stopping():
                    self._terminate(process)
                    raise Aborted('Guide native download aborted')
                if time.monotonic() > deadline:
                    self._terminate(process)
                    raise ValueError('Native guide download exceeded time limit')
                if self.monitor.waitForAbort(.25):
                    self._terminate(process)
                    raise Aborted('Guide native download aborted')
            stdout, stderr = process.communicate(timeout=1)
            if process.returncode != 0:
                raise ValueError('Windows guide download failed (' + str(process.returncode) + '): ' +
                                 stderr.decode('utf-8', errors='replace')[-500:])
            if stdout.strip() != b'200':
                raise ValueError('Native guide HTTP status ' + stdout.decode('ascii', errors='replace')[-10:])
            total = part.stat().st_size
            if not total or total > cfg['max_bytes']:
                raise ValueError('Native guide response is empty or exceeds size limit')
            return total
        finally:
            if process.poll() is None:
                self._terminate(process)

    def run_once(self):
        """Return a bounded next-check delay; failures get a separate retry pace."""
        if self.stopping():
            return 0
        try:
            cfg = configuration(self.cache_dir / 'active.json')
            if cfg is None:
                self._configuration_key = None
                self._existing_checked = False
                return 30
            key = json.dumps(cfg, sort_keys=True)
            guide = self.cache_dir / 'guide.xml'
            if key != self._configuration_key:
                self._configuration_key = key
                self._existing_checked = False
                self._next_attempt = 0
            if not self._existing_checked:
                self._existing_checked = True
                if guide.is_file():
                    try:
                        if guide.stat().st_size > cfg['max_bytes']:
                            raise ValueError('Existing guide exceeds configured size limit')
                        counts = validate_xml(guide, self.stopping)
                        self._next_attempt = min(self.clock() + cfg['refresh_seconds'],
                                                 guide.stat().st_mtime + cfg['refresh_seconds'])
                        self._status({'state': 'ready', 'url': cfg['url'],
                                      'last_success': guide.stat().st_mtime,
                                      'bytes': guide.stat().st_size, **counts})
                    except (ValueError, ET.ParseError):
                        self._next_attempt = 0
            if self.clock() < self._next_attempt:
                return min(30, max(0, self._next_attempt - self.clock()))
            try:
                self.refresh(cfg)
                self._next_attempt = self.clock() + cfg['refresh_seconds']
            except Aborted:
                return 0
            except Exception as exc:
                self._next_attempt = self.clock() + cfg['retry_seconds']
                self._status({'state': 'retry_pending', 'last_attempt': self.clock(),
                              'next_attempt': self._next_attempt, 'error': str(exc),
                              'retained_last_guide': guide.is_file()})
                xbmc.log('JVBuilt EPG refresh failed; keeping last guide: ' + str(exc), xbmc.LOGWARNING)
            return min(30, max(0, self._next_attempt - self.clock()))
        except Aborted:
            return 0
        except Exception as exc:
            xbmc.log('JVBuilt EPG configuration failed: ' + str(exc), xbmc.LOGWARNING)
            return 30

    def _run(self):
        xbmc.log('JVBuilt EPG cache service started', xbmc.LOGINFO)
        try:
            while not self.stopping():
                delay = self.run_once()
                deadline = time.monotonic() + max(.1, delay)
                while not self.stopping() and time.monotonic() < deadline:
                    if self.monitor.waitForAbort(min(.5, max(.01, deadline - time.monotonic()))):
                        break
        finally:
            xbmc.log('JVBuilt EPG cache service stopped', xbmc.LOGINFO)

    def start(self):
        if self.thread is not None and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self._run, name='JVBuilt EPG cache', daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        if self.thread is not None and self.thread is not threading.current_thread():
            self.thread.join(2.5)
