"""Scoped PVR and optional Video Games menu migration for release 6.4.14."""
from pathlib import Path
import copy
import hashlib
import json
import xml.etree.ElementTree as ET

PROFILE = Path('userdata/addon_data/service.jvbuilt.pvr.channels')
SHORTCUTS = Path('userdata/addon_data/script.skinshortcuts')
LOCAL = 'special://profile/addon_data/service.jvbuilt.pvr.channels/channels.m3u'
MIGRATION_ID = 'pvr-games-6.4.14'


def _games(node):
    action = (node.findtext('action') or '').lower()
    ident = (node.findtext('defaultID') or '').lower()
    label = (node.findtext('label') or '').strip().lower()
    return ident in ('video-games', 'videogames') or label == 'video games' or 'script.jvbuilt.games' in action or 'plugin://plugin.program.iagl' in action


def prepare(payload):
    payload = Path(payload)
    setup = json.loads((payload / 'userdata/jvbuilt_setup.json').read_text())
    if setup.get('version') != '6.4.14':
        return None
    main = ET.parse(payload / SHORTCUTS / 'mainmenu.DATA.xml').getroot()
    game = next(n for n in main if _games(n))
    return {'version': '6.4.14', 'game': ET.tostring(game),
            'submenu': (payload / SHORTCUTS / 'video-games.DATA.xml').read_bytes(),
            'profile': {n: (payload / PROFILE / n).read_bytes() for n in ('config.json', 'channels.m3u', 'status.json')}}


def apply(home, payload, recovery, plan):
    if plan is None:
        return {'applied': False, 'changed_files': []}
    home, payload, recovery = map(Path, (home, payload, recovery))
    marker = Path('userdata/jvbuilt_release_migrations.json')
    previous = json.loads((home / marker).read_text()) if (home / marker).exists() else {}
    if MIGRATION_ID in previous.get('applied', []):
        return {'applied': False, 'reason': 'already_applied', 'changed_files': []}
    changes = []

    def put(relative, data):
        path = payload / relative
        before = path.read_bytes() if path.exists() else None
        if before == data:
            return
        if data is None:
            path.unlink()
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        changes.append({'path': relative.as_posix(),
                        'before_sha256': hashlib.sha256(before).hexdigest() if before is not None else None,
                        'after_sha256': hashlib.sha256(data).hexdigest() if data is not None else None})

    main_path = SHORTCUTS / 'mainmenu.DATA.xml'
    main = ET.parse(payload / main_path).getroot()
    games = next((n for n in main if _games(n)), None)
    added_menu = games is None
    if added_menu:
        games = ET.fromstring(plan['game'])
        index = next((i for i, n in enumerate(main) if n.findtext('defaultID') == 'settings'), len(main))
        main.insert(index, games)
        put(main_path, ET.tostring(main, encoding='utf-8', xml_declaration=True))
    # Use the existing menu key; preserve all existing submenu entries and paths.
    key = games.findtext('defaultID') or 'video-games'
    if '/' in key or '\\' in key or key in ('.', '..'):
        raise ValueError('Unsafe games menu key')
    submenu_path = SHORTCUTS / (key + '.DATA.xml')
    submenu = ET.parse(payload / submenu_path).getroot() if (payload / submenu_path).exists() else ET.Element('shortcuts')
    actions = {n.findtext('action') for n in submenu}
    changed = False
    for node in ET.fromstring(plan['submenu']):
        action = node.findtext('action') or ''
        # Existing local-games path belongs to this device.
        if node.findtext('label') == 'Local Games' and any(n.findtext('label') == 'Local Games' for n in submenu):
            continue
        if action not in actions:
            submenu.append(copy.deepcopy(node)); actions.add(action); changed = True
    if changed:
        put(submenu_path, ET.tostring(submenu, encoding='utf-8', xml_declaration=True))

    # Only replace the known Doms Guide playlist. Keep custom providers intact.
    configured = []
    for settings in sorted((payload / 'userdata/addon_data/pvr.iptvsimple').glob('instance-settings-*.xml')):
        root = ET.parse(settings).getroot()
        values = {n.get('id'): n.text or '' for n in root}
        if not any(v in (LOCAL, 'https://s.id/d9Kod') for v in (values.get('m3uPath'), values.get('m3uUrl'))):
            continue
        for k, value in {'m3uPathType': '0', 'm3uPath': LOCAL, 'm3uUrl': ''}.items():
            node = root.find("setting[@id='%s']" % k)
            if node is None: node = ET.SubElement(root, 'setting', id=k)
            node.attrib.pop('default', None); node.text = value
        put(settings.relative_to(payload), ET.tostring(root, encoding='utf-8', xml_declaration=True))
        configured.append(settings.name)
    if configured:
        new = json.loads(plan['profile']['config.json'])
        existing = payload / PROFILE / 'config.json'
        old = json.loads(existing.read_text()) if existing.exists() else {}
        if old.get('source_url', new['source_url']) == new['source_url']:
            # Retain additional same-device exclusions and refresh preferences.
            seen = {json.dumps(r, sort_keys=True) for r in new['excluded']}
            new['excluded'].extend(r for r in old.get('excluded', []) if json.dumps(r, sort_keys=True) not in seen)
            new['excluded_groups'] = sorted(set(new['excluded_groups'] + old.get('excluded_groups', [])))
            new['refresh_seconds'] = old.get('refresh_seconds', new['refresh_seconds'])
            put(PROFILE / 'config.json', json.dumps(new, indent=2).encode())
            # Apply extra personal exclusions to the release playlist as well.
            import importlib.util
            module_path = payload / 'addons/service.jvbuilt.pvr.channels/transform.py'
            spec = importlib.util.spec_from_file_location('release_pvr_transform', str(module_path))
            module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
            header, blocks = module.parse(plan['profile']['channels.m3u'].decode())
            rules = new['excluded']
            kept = [b for b in blocks if not any(r.get('name') == module.name(b) and ('tvg_id' not in r or r['tvg_id'] == module.attrs(b[0]).get('tvg-id', '')) for r in rules)]
            data = (''.join(header) + ''.join(''.join(b) for b in kept)).encode()
            put(PROFILE / 'channels.m3u', data)
            status = json.loads(plan['profile']['status.json']); status.update(last_success=0, output_count=len(kept), sha256=hashlib.sha256(data).hexdigest())
            put(PROFILE / 'status.json', json.dumps(status, indent=2).encode())
    cached = SHORTCUTS / 'skin.arctic.zephyr.mod.hash'
    if changes and (payload / cached).exists(): put(cached, None)
    previous.setdefault('applied', []).append(MIGRATION_ID)
    put(marker, json.dumps(previous, indent=2).encode())
    receipt = {'id': MIGRATION_ID, 'applied': True, 'added_games_menu': added_menu,
               'pvr_instances': configured, 'changed_files': changes}
    recovery.mkdir(parents=True, exist_ok=True)
    (recovery / 'pvr-games-migration.json').write_text(json.dumps(receipt, indent=2))
    return receipt
