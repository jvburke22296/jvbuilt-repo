"""Deferred Windows clean install. Kept outside Kodi's data directory."""
import os,sys,json,time,hashlib,zipfile,shutil,subprocess,traceback
from pathlib import Path


def validate_enabled_registry(archive, work_dir=None):
    import sqlite3,tempfile
    from contextlib import closing
    registry='userdata/Database/Addons33.db'
    if registry not in archive.namelist():raise ValueError('Build is missing its add-on registry; no purge will be performed')
    with tempfile.TemporaryDirectory(prefix='JVBuilt-registry-check-', dir=work_dir) as tmp:
        database=Path(tmp)/'Addons33.db';database.write_bytes(archive.read(registry))
        try:
            with closing(sqlite3.connect(str(database))) as conn:
                for addon in ['plugin.program.jvbuiltwizard','script.module.requests','script.module.six']:
                    row=conn.execute('SELECT enabled,disabledReason FROM installed WHERE addonID=?',(addon,)).fetchone()
                    if row is None or row[0]!=1 or row[1]!=0:
                        raise ValueError('Build add-on registry does not enable '+addon+'. Download the corrected build; no purge will be performed.')
        except sqlite3.Error as exc:
            raise ValueError('Build add-on registry is unreadable; no purge will be performed') from exc

def validate_archive(package, digest):
    h=hashlib.sha256()
    with package.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    if h.hexdigest()!=digest:
        raise ValueError('Build checksum mismatch')
    with zipfile.ZipFile(package) as z:
        names=z.namelist()
        for info in z.infolist():
            n=info.filename.replace('\\','/')
            if n.startswith('/') or ':' in n or '..' in n.split('/') or (info.external_attr>>16)&0o170000==0o120000:
                raise ValueError('Unsafe archive entry')
        if 'userdata/guisettings.xml' not in names:raise ValueError('Missing build settings')
        if z.testzip():raise ValueError('Corrupt build archive')
        validate_enabled_registry(z, str(package.parent))

def replace_data(home, package):
    import preserve_device
    recovery=package.parent
    payload=recovery/'payload'
    payload.mkdir()
    with zipfile.ZipFile(package) as z:z.extractall(payload)
    preserve_device.stage(home,payload,recovery)
    preserve_device.activate(home,payload,recovery)


def main(jobpath):
    job=json.loads(Path(jobpath).read_text())
    if getattr(os.lstat(job['home']),'st_file_attributes',0)&1024:
        raise ValueError('Kodi data folder must not be a filesystem link')
    home=Path(job['home']).resolve()
    expected=(Path(os.environ['APPDATA'])/'Kodi').resolve()
    if home!=expected or home.is_symlink() or getattr(home,'is_junction',lambda:False)():
        raise ValueError('Only the default Windows Kodi data directory is supported')
    package=Path(job['package']).resolve()
    if home==package or home in package.parents:raise ValueError('Installer package must be outside Kodi data')
    validate_archive(package,job['sha256'])
    # Wait for the process that launched this worker to finish cleanly.
    for _ in range(180):
        listing=subprocess.check_output(['tasklist','/FI','IMAGENAME eq kodi.exe','/FO','CSV','/NH'],text=True)
        if 'kodi.exe' not in listing.lower():break
        time.sleep(1)
    else:raise RuntimeError('Kodi is still running; no data was removed')
    replace_data(home,package)
    Path(jobpath).with_suffix('.complete').write_text('JVBuilt clean install completed')
    subprocess.Popen([job['kodi']])

if __name__=='__main__':
    try:main(sys.argv[1])
    except Exception:
        Path(sys.argv[1]).with_suffix('.error.txt').write_text(traceback.format_exc())
        raise
