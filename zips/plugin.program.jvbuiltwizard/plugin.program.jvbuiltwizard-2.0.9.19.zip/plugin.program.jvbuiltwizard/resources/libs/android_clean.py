"""Fully stage an Android build, strictly purge the old profile, then exit Kodi."""
import os
import shutil
from pathlib import Path

def validate_home(value):
    raw=Path(value)
    if raw.is_symlink():raise ValueError('Kodi data folder must not be a link')
    home=raw.resolve()
    if not home.as_posix().endswith('/Android/data/org.xbmc.kodi/files/.kodi'):
        raise ValueError('This installer requires the standard org.xbmc.kodi Android data folder')
    return home

def validate_stage(home,folder):
    home=validate_home(home);folder=Path(folder).resolve()
    if folder.parent!=home.parent or not folder.name.startswith('.jvbuilt-clean-') or folder.is_symlink():
        raise ValueError('Staging folder must be an installer sibling of .kodi')
    return home,folder

def prepare(home,folder,package,progress):
    import zipfile
    home,folder=validate_stage(home,folder)
    payload=folder/'payload';payload.mkdir()
    with zipfile.ZipFile(package) as z:
        required=sum(i.file_size for i in z.infolist())+64*1024*1024
        available=shutil.disk_usage(folder).free
        if available<required:
            raise ValueError('Not enough storage to stage a clean install. Need %.0f MB; have %.0f MB. No existing data was removed.'%(required/1048576,available/1048576))
        items=z.infolist()
        for index,item in enumerate(items):
            if progress.iscanceled():raise ValueError('Installation cancelled before purge')
            z.extract(item,payload)
            if index%30==0:progress.update(int((index+1)*100/len(items)),'Preparing fresh build before removing any data…')
    if not (payload/'userdata/guisettings.xml').is_file():raise ValueError('Prepared build lacks its settings')
    from resources.libs import preserve_device
    preserve_device.stage(home,payload,folder)
    return payload

def install_prepared(home,folder):
    home,folder=validate_stage(home,folder);payload=folder/'payload'
    if payload.is_symlink() or not(payload/'userdata/guisettings.xml').is_file():raise ValueError('Prepared build is missing')
    from resources.libs import preserve_device
    preserve_device.activate(home,payload,folder)


def handoff(payload,folder):
    install_prepared(folder.parent/'.kodi',folder)
    # Skip Kodi's shutdown save so cached settings cannot overwrite the fresh build.
    os._exit(0)
