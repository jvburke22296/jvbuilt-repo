"""Refresh only this add-on's data; publish a complete validated set."""
import gzip
import hashlib
import json
import pathlib
import shutil
import tempfile
from datetime import datetime, timezone

from config import SOURCES
from core import _publish, build_lists, guide_channels, parse_m3u
from switcher import atomic_write


class Cancelled(Exception):
    pass


def ensure_jvbuilt(profile, addon_path):
    presets = pathlib.Path(addon_path) / 'resources/presets'
    metadata = json.loads((presets / 'jvbuilt.json').read_text(encoding='utf-8'))
    source = presets / 'jvbuilt.m3u'
    data = source.read_bytes()
    if hashlib.sha256(data).hexdigest() != metadata['sha256']:
        raise ValueError('Bundled JVBuilt PVR playlist hash mismatch')
    if len(parse_m3u(source)) != metadata['channels']:
        raise ValueError('Bundled JVBuilt PVR playlist channel count mismatch')
    atomic_write(pathlib.Path(profile) / 'lists/jvbuilt.m3u', data)


def refresh(profile, addon_path, fetch, cancelled=lambda: False, progress=lambda n, label: None):
    profile = pathlib.Path(profile); profile.mkdir(parents=True, exist_ok=True)
    catalog = json.loads((pathlib.Path(addon_path) / 'resources/catalog.json').read_text(encoding='utf-8'))
    with tempfile.TemporaryDirectory(prefix='.download-', dir=str(profile)) as folder:
        playlists, guides, hashes = {}, {}, {}
        for index, (name, (kind, provider, url)) in enumerate(SOURCES.items()):
            if cancelled():
                raise Cancelled('Refresh cancelled')
            progress(int(index * 85 / len(SOURCES)), 'Downloading ' + name.replace('_', ' '))
            path = pathlib.Path(folder) / (name + '.dat')
            fetch(url, path, cancelled)
            hashes[name] = hashlib.sha256(path.read_bytes()).hexdigest()
            (playlists if kind == 'playlist' else guides)[provider] = path
        if cancelled():
            raise Cancelled('Refresh cancelled')
        progress(90, 'Building sports guide')
        result = build_lists(catalog, playlists, guides, profile / 'lists', datetime.now(timezone.utc), source_hashes=hashes)
    progress(100, 'Sports guide updated')
    return result


def ensure_seed(profile, addon_path):
    lists = pathlib.Path(profile) / 'lists'
    if (lists / 'sports.m3u').exists() and (lists / 'sports.xml').exists():
        return
    seed = pathlib.Path(addon_path) / 'resources/seed'
    lists.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.seed-', dir=str(lists)) as folder:
        staging = pathlib.Path(folder)
        shutil.copyfile(seed / 'sports.m3u', staging / 'sports.m3u')
        from core import open_guide
        with open_guide(seed / 'sports.xml.gz') as source, open(staging / 'sports.xml', 'wb') as target:
            shutil.copyfileobj(source, target)
        shutil.copyfile(seed / 'coverage.json', staging / 'coverage.json')
        parse_m3u(staging / 'sports.m3u'); guide_channels(staging / 'sports.xml')
        _publish(staging, lists, ('sports.m3u', 'sports.xml', 'coverage.json'))
