"""Small Kodi boundary. List construction and recovery live in pure modules."""
import contextlib
import json
import os
import pathlib
import time
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from config import PVR_ID
from switcher import Switcher, atomic_write, read_state
from updater import Cancelled, ensure_jvbuilt, ensure_seed, refresh

TITLE = 'JVBuilt and Sports'


def paths():
    addon = xbmcaddon.Addon()
    profile = pathlib.Path(xbmcvfs.translatePath(addon.getAddonInfo('profile')))
    install = pathlib.Path(xbmcvfs.translatePath(addon.getAddonInfo('path')))
    iptv = pathlib.Path(xbmcvfs.translatePath('special://profile/addon_data/' + PVR_ID))
    return profile, install, iptv


def rpc(method, params):
    return json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))


@contextlib.contextmanager
def operation(profile):
    profile = pathlib.Path(profile); profile.mkdir(parents=True, exist_ok=True)
    lock = profile / 'operation.lock'
    # Only this add-on creates the lock. Recover a lock left by a crashed Kodi.
    if lock.exists() and time.time() - lock.stat().st_mtime > 1800:
        lock.unlink()
    try:
        handle = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        raise RuntimeError('A PVR setup update is already running. Please try again shortly.')
    try:
        os.close(handle)
        yield
    finally:
        lock.unlink(missing_ok=True)


def download(url, path, cancelled):
    """Fixed public source URLs, verified TLS, bounded HTTPS redirects/size."""
    with requests.Session() as session:
        session.headers['User-Agent'] = 'JVBuilt-and-Sports/1.1 (Kodi)'
        for attempt in range(6):
            if cancelled(): raise Cancelled('Refresh cancelled')
            if urlparse(url).scheme != 'https':
                raise ValueError('Guide downloads require HTTPS')
            with session.get(url, timeout=(10, 30), stream=True, allow_redirects=False) as response:
                if response.status_code in (301, 302, 303, 307, 308):
                    url = urljoin(url, response.headers.get('Location', ''))
                    continue
                response.raise_for_status()
                total = 0
                deadline = time.monotonic() + 120
                with open(path, 'wb') as target:
                    for chunk in response.iter_content(chunk_size=64 * 1024):
                        if cancelled(): raise Cancelled('Refresh cancelled')
                        if time.monotonic() > deadline: raise TimeoutError('Source download timed out')
                        total += len(chunk)
                        if total > 64 * 1024 * 1024: raise ValueError('Source download exceeds 64 MiB limit')
                        target.write(chunk)
                if not total: raise ValueError('Source download is empty')
                return
        raise ValueError('Too many source redirects')


def coverage(profile):
    try:
        return json.loads((pathlib.Path(profile) / 'lists/coverage.json').read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}


def age_seconds(profile):
    try:
        stamp = datetime.fromisoformat(coverage(profile)['generated_utc'])
        return (datetime.now(timezone.utc) - stamp).total_seconds()
    except (KeyError, ValueError, TypeError):
        return float('inf')


def run_refresh(profile, install, interactive=True):
    monitor = xbmc.Monitor()
    dialog = xbmcgui.DialogProgress() if interactive else None
    if dialog: dialog.create(TITLE, 'Downloading sports channels and guide')
    try:
        result = refresh(profile, install, download,
            cancelled=lambda: monitor.abortRequested() or bool(dialog and dialog.iscanceled()),
            progress=lambda percent, text: dialog.update(percent, text) if dialog else None)
        atomic_write(pathlib.Path(profile) / 'refresh-status.json', json.dumps({'last_success_utc': result['generated_utc'], 'failed': False}).encode('utf-8'))
        return result
    except Exception as error:
        # Avoid logging stream URLs, query strings or request exception text.
        atomic_write(pathlib.Path(profile) / 'refresh-status.json', json.dumps({'failed': True, 'error_type': type(error).__name__, 'time_utc': datetime.now(timezone.utc).isoformat()}).encode('utf-8'))
        raise
    finally:
        if dialog: dialog.close()


def show_status(profile, switcher):
    report = coverage(profile); state = read_state(profile)
    channels = report.get('channels', [])
    text = ('Selected list: {mode}\nSports channels: {channels} ({epg} with a guide)\n'
            'Programme listings: {programmes}\nUpdated (UTC): {updated}\n'
            'Schedule catalog: {catalog}\nGames with channel candidates: {games}\n'
            'Guide-only games without a stream: {unresolved}\n\n'
            'Channel/EPG matches do not confirm playback or regional carriage. '
            'Sports sources refresh every six hours while this list is active. '
            'JVBuilt PVR uses the saved 76-channel personal list and its upstream guide.').format(
        mode={'jvbuilt': 'JVBuilt PVR', 'sports': 'NFL & NBA Sports'}.get(state.get('mode'), 'Not selected'), channels=len(channels), epg=sum(bool(c.get('guide_provider')) for c in channels),
        programmes=report.get('programmes', 0), updated=report.get('generated_utc', 'Not downloaded'),
        catalog=report.get('catalog_as_of', '2026-11-16'), games=len(report.get('covered_games', [])), unresolved=len(report.get('unresolved_games', [])))
    if state.get('mode') in ('sports', 'jvbuilt') and not switcher.owns_current():
        text += '\n\nIPTV settings have changed elsewhere. Automatic updates are paused.'
    try:
        if json.loads((pathlib.Path(profile) / 'refresh-status.json').read_text()).get('failed'):
            text += '\n\nThe latest refresh failed or was cancelled. The previous complete list is retained.'
    except (OSError, ValueError):
        pass
    xbmcgui.Dialog().textviewer(TITLE, text)


def run_menu():
    profile, install, iptv = paths()
    switcher = Switcher(profile, iptv, rpc)
    choice = xbmcgui.Dialog().select(TITLE, [
        'Enable JVBuilt PVR', 'Enable NFL & NBA Sports',
        'Refresh Sports channels and EPG', 'Open TV guide',
        'List status and coverage', 'Restore previous IPTV Simple settings'])
    if choice < 0: return
    try:
        if choice == 3:
            xbmc.executebuiltin('ActivateWindow(TVGuide)'); return
        if choice == 4:
            show_status(profile, switcher); return
        close_kodi = False
        with operation(profile):
            if choice == 0:
                ensure_jvbuilt(profile, install)
                switcher.activate('jvbuilt')
                xbmcgui.Dialog().notification(TITLE, 'JVBuilt PVR enabled. Kodi is closing; reopen Kodi.', time=6000)
                close_kodi = True
            elif choice == 1:
                ensure_seed(profile, install)
                if age_seconds(profile) > 24 * 60 * 60:
                    run_refresh(profile, install)
                switcher.activate('sports')
                xbmcgui.Dialog().notification(TITLE, 'Sports enabled. Kodi is closing; reopen Kodi.', time=6000)
                close_kodi = True
            elif choice == 2:
                result = run_refresh(profile, install)
                xbmcgui.Dialog().notification(TITLE, '{} sports channels updated'.format(len(result['channels'])), time=6000)
            elif choice == 5:
                switcher.restore()
                xbmcgui.Dialog().notification(TITLE, 'Previous IPTV settings restored', time=6000)
        # Release the file-operation lock before Kodi exits.
        if close_kodi:
            xbmc.sleep(1000)
            xbmc.executebuiltin('Quit')
    except Cancelled:
        xbmcgui.Dialog().notification(TITLE, 'Refresh cancelled; previous list retained', time=6000)
    except Exception as error:
        xbmc.log('[JVBuilt Sports Setup] Operation failed: ' + type(error).__name__, xbmc.LOGWARNING)
        xbmcgui.Dialog().ok(TITLE, 'The operation could not finish ({0}). The last complete list is retained.\n\nCheck that IPTV Simple is installed and the internet is available. Restore will not overwrite settings changed elsewhere.'.format(type(error).__name__))
