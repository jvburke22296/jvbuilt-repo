"""Refresh our sports files only while our Sports preset still owns the client."""
import time

import xbmc

from config import REFRESH_SECONDS
from runtime import age_seconds, operation, paths, rpc, run_refresh
from switcher import Switcher, read_state


def run():
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(30): return
    profile, install, iptv = paths()
    switcher = Switcher(profile, iptv, rpc)
    next_attempt = 0
    while not monitor.abortRequested():
        if time.monotonic() >= next_attempt:
            try:
                if read_state(profile).get('mode') == 'sports' and age_seconds(profile) >= REFRESH_SECONDS and switcher.owns_current():
                    with operation(profile):
                        run_refresh(profile, install, interactive=False)
                next_attempt = time.monotonic() + 300
            except Exception as error:
                xbmc.log('[JVBuilt Sports Setup] Background update failed: ' + type(error).__name__, xbmc.LOGWARNING)
                next_attempt = time.monotonic() + 1800
        if monitor.waitForAbort(60): break


if __name__ == '__main__':
    run()
