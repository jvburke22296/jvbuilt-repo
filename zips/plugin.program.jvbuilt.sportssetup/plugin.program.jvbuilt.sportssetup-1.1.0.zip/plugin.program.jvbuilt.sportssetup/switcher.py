"""IPTV Simple configuration switching with local recovery."""
import hashlib
import json
import os
import pathlib
import re
import uuid
import xml.etree.ElementTree as ET

from config import DOMS_GUIDE, PVR_ID
from core import guide_channels, parse_m3u


def digest(data):
    return hashlib.sha256(data).hexdigest()


def atomic_write(path, data):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.new-' + uuid.uuid4().hex)
    try:
        with open(temp, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(str(temp), str(path))
    finally:
        if temp.exists():
            temp.unlink()


def read_state(profile):
    try:
        value = json.loads((pathlib.Path(profile) / 'active.json').read_text(encoding='utf-8'))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


class Switcher:
    def __init__(self, profile, iptv_profile, rpc):
        self.profile = pathlib.Path(profile)
        self.iptv_profile = pathlib.Path(iptv_profile)
        self.rpc = rpc

    def _files(self):
        files = {}
        if self.iptv_profile.exists():
            for path in self.iptv_profile.glob('instance-settings-*.xml'):
                if not re.fullmatch(r'instance-settings-\d+\.xml', path.name) or path.is_symlink():
                    raise ValueError('Unexpected or redirected IPTV instance file')
                files[path.name] = path.read_bytes()
        return files

    def _client_enabled(self):
        value = self.rpc('Addons.GetAddonDetails', {'addonid': PVR_ID, 'properties': ['enabled']})
        enabled = value.get('result', {}).get('addon', {}).get('enabled')
        if value.get('error') or not isinstance(enabled, bool):
            raise RuntimeError('IPTV Simple client is not available; install it from the Kodi repository first')
        return enabled

    def _enable(self, enabled):
        value = self.rpc('Addons.SetAddonEnabled', {'addonid': PVR_ID, 'enabled': enabled})
        if value.get('error') or value.get('result') != 'OK' or self._client_enabled() != enabled:
            raise RuntimeError('Kodi did not confirm the IPTV Simple client state')

    def _replace_files(self, wanted):
        self.iptv_profile.mkdir(parents=True, exist_ok=True)
        for name, data in wanted.items():
            if not re.fullmatch(r'instance-settings-\d+\.xml', name):
                raise ValueError('Invalid instance filename')
            atomic_write(self.iptv_profile / name, data)
        for name in set(self._files()) - set(wanted):
            (self.iptv_profile / name).unlink()

    def _snapshot(self, files, previous_enabled):
        key = 'backup-' + uuid.uuid4().hex
        folder = self.profile / 'backups' / key
        folder.mkdir(parents=True)
        for name, data in files.items():
            atomic_write(folder / name, data)
        manifest = {'files': {n: digest(d) for n, d in files.items()}, 'client_enabled': previous_enabled}
        atomic_write(folder / 'manifest.json', json.dumps(manifest, indent=2).encode('utf-8'))
        return key

    def _backup(self, key):
        if not re.fullmatch(r'backup-[0-9a-f]{32}', key or ''):
            raise ValueError('Invalid recovery identity')
        folder = self.profile / 'backups' / key
        manifest = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
        files = {}
        for name, expected in manifest['files'].items():
            if not re.fullmatch(r'instance-settings-\d+\.xml', name):
                raise ValueError('Invalid recovery filename')
            data = (folder / name).read_bytes()
            if digest(data) != expected:
                raise ValueError('Recovery file hash mismatch')
            files[name] = data
        if not isinstance(manifest.get('client_enabled'), bool):
            raise ValueError('Recovery client state is missing')
        return files, manifest['client_enabled']

    def owns_current(self):
        state = read_state(self.profile)
        return bool(state.get('owned_hashes')) and {n: digest(d) for n, d in self._files().items()} == state.get('owned_hashes')

    @staticmethod
    def _xml(data, changes):
        root = ET.fromstring(data) if data else ET.Element('settings', {'version': '2'})
        for name, value in changes.items():
            item = next((e for e in root if e.get('id') == name), None)
            if item is None:
                item = ET.SubElement(root, 'setting', {'id': name})
            item.attrib.pop('default', None)
            item.text = str(value)
        return ET.tostring(root, encoding='utf-8', xml_declaration=True)

    def activate(self, mode):
        if mode not in ('sports', 'jvbuilt'):
            raise ValueError('Unknown list choice')
        if mode == 'sports':
            parse_m3u(self.profile / 'lists/sports.m3u')
            guide_channels(self.profile / 'lists/sports.xml')
        else:
            parse_m3u(self.profile / 'lists/jvbuilt.m3u')
        previous_enabled = self._client_enabled()
        originals = self._files()
        state = read_state(self.profile)
        backup = state['backup'] if self.owns_current() else self._snapshot(originals, previous_enabled)
        # Validate an existing original backup before changing a second preset.
        self._backup(backup)
        changed = dict(originals)
        for name in changed:
            changed[name] = self._xml(changed[name], {'kodi_addon_instance_enabled': 'false'})
        values = {'kodi_addon_instance_name': 'JVBuilt NFL & NBA Sports' if mode == 'sports' else 'JVBuilt PVR', 'kodi_addon_instance_enabled': 'true', 'm3uRefreshMode': '1', 'm3uRefreshIntervalMins': '60', 'epgTimeShift': '0', 'epgTSOverride': 'false'}
        # Filters from another source can hide every group in a new playlist.
        values.update({'tvGroupMode': '0', 'radioGroupMode': '0', 'tvChannelGroupsOnly': 'false', 'radioChannelGroupsOnly': 'false', 'numberByOrder': 'true', 'startNum': '1'})
        if mode == 'sports':
            values.update({'m3uPathType': '0', 'm3uPath': str(self.profile / 'lists/sports.m3u'), 'm3uUrl': '', 'epgPathType': '0', 'epgPath': str(self.profile / 'lists/sports.xml'), 'epgUrl': ''})
        else:
            values.update({'m3uPathType': '0', 'm3uPath': str(self.profile / 'lists/jvbuilt.m3u'), 'm3uUrl': '', 'epgPathType': '1', 'epgPath': '', 'epgUrl': DOMS_GUIDE, 'epgCache': 'true'})
        changed['instance-settings-1.xml'] = self._xml(originals.get('instance-settings-1.xml'), values)
        touched = False
        try:
            self._enable(False)
            touched = True
            self._replace_files(changed)
            self._enable(True)
            result = {'mode': mode, 'backup': backup, 'owned_hashes': {n: digest(d) for n, d in changed.items()}}
            atomic_write(self.profile / 'active.json', json.dumps(result, indent=2).encode('utf-8'))
        except Exception:
            if touched:
                if self._client_enabled():
                    self._enable(False)
                self._replace_files(originals)
            if self._client_enabled() != previous_enabled:
                self._enable(previous_enabled)
            raise
        return result

    def restore(self):
        if not self.owns_current():
            raise RuntimeError('IPTV settings changed outside this add-on; automatic restore will not overwrite them')
        state = read_state(self.profile)
        originals, previous_enabled = self._backup(state['backup'])
        current = self._files()
        enabled = self._client_enabled()
        touched = False
        try:
            self._enable(False)
            touched = True
            self._replace_files(originals)
            self._enable(previous_enabled)
            restored = {'restored_backup': state['backup'], 'mode': 'restored'}
            atomic_write(self.profile / 'active.json', json.dumps(restored, indent=2).encode('utf-8'))
        except Exception:
            if touched:
                if self._client_enabled():
                    self._enable(False)
                self._replace_files(current)
            if self._client_enabled() != enabled:
                self._enable(enabled)
            raise
        return restored
