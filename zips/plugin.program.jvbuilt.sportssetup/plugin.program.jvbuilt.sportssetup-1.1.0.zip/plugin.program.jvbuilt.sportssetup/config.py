"""Fixed source and client identities for this private build add-on."""
PVR_ID = 'pvr.iptvsimple'
DOMS_PLAYLIST = 'https://raw.githubusercontent.com/doms9/iptv/refs/heads/default/M3U8/kodi.m3u8'
DOMS_GUIDE = 'https://raw.githubusercontent.com/doms9/iptv/refs/heads/default/M3U8/TV.xml'
SOURCES = {
    'doms_playlist': ('playlist', 'doms', DOMS_PLAYLIST),
    'doms_guide': ('guide', 'doms', DOMS_GUIDE),
    'loop_playlist': ('playlist', 'loop', 'https://bit.ly/4oo63xG'),
    'loop_guide': ('guide', 'loop', 'https://loopaddon.uk/files/k19/epg2025/final_epg.xml.gz'),
    'mt_playlist': ('playlist', 'mt', 'https://magnetic.website/jet/playlists/titan.m3u8'),
    'epgtalk_guide': ('guide', 'epgtalk', 'https://raw.githubusercontent.com/acidjesuz/EPGTalk/master/guide.xml.gz'),
}
REFRESH_SECONDS = 6 * 60 * 60
