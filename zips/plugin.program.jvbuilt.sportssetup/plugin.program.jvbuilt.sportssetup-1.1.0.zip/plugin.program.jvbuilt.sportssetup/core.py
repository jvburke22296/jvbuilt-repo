"""Build Sports and Doms lists without importing or controlling Kodi."""
import gzip
import hashlib
import json
import os
import pathlib
import re
import shutil
import tempfile
import unicodedata
import xml.etree.ElementTree as ET
from datetime import datetime, timezone, timedelta

TRUSTED_GUIDES = ('doms', 'loop', 'epgtalk')


def clean_name(value):
    return re.sub(r'\[/?(?:COLOR|B|I)[^\]]*\]', '', value, flags=re.I).strip()


def normalize(value):
    value = unicodedata.normalize('NFKD', clean_name(value)).encode('ascii', 'ignore').decode().lower()
    return re.sub(r'[^a-z0-9]+', ' ', value).strip()


def canonical(value):
    name = normalize(value)
    name = re.sub(r'\s+(?:hd|usa|us)$', '', name)
    aliases = {'espn 2': 'espn2', 'chsn chicago sports network': 'chicago sports network', 'spectrum sportsnet': 'spectrum sportsnet lakers', 'nbc sport network': 'nbc sports network', 'msg national': 'msg'}
    return aliases.get(name, name)


def region(channel_id, name):
    match = re.search(r'\.([a-z]{2})\d*$', channel_id.lower())
    if match:
        return match.group(1)
    label = normalize(name)
    if re.search(r'\b(?:usa|us)\b', label):
        return 'us'
    if re.match(r'^(?:tsn|sportsnet)\b', label):
        return 'ca'
    return ''


def parse_m3u(path):
    text = pathlib.Path(path).read_text(encoding='utf-8-sig', errors='replace')
    if not text.lstrip().startswith('#EXTM3U'):
        raise ValueError('Source is not an extended M3U playlist')
    entries = []
    current = None
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith('#EXTINF:'):
            attrs = {m.group(1): m.group(3) for m in re.finditer(r'''([\w-]+)=(["'])(.*?)\2''', line)}
            quote = None
            comma = -1
            for i, char in enumerate(line):
                if char in ('"', "'"):
                    quote = None if quote == char else char if quote is None else quote
                elif char == ',' and quote is None:
                    comma = i
                    break
            if comma < 0:
                raise ValueError('Playlist entry has no display name separator')
            current = {'name': line[comma + 1:], 'attrs': attrs, 'extinf': line, 'options': [], 'url': '', 'original_id': attrs.get('tvg-id', '')}
        elif current is not None and line.startswith('#'):
            current['options'].append(line)
        elif current is not None:
            current['url'] = line
            entries.append(current)
            current = None
    if current is not None or not entries:
        raise ValueError('Playlist contains no complete channels or ends with an incomplete entry')
    return entries


class LimitedReader:
    def __init__(self, stream, limit=128 * 1024 * 1024):
        self.stream, self.remaining = stream, limit

    def read(self, size=-1):
        size = self.remaining + 1 if size < 0 else min(size, self.remaining + 1)
        data = self.stream.read(size)
        self.remaining -= len(data)
        if self.remaining < 0:
            raise ValueError('Decoded guide exceeds 128 MiB limit')
        return data

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.stream.close()


def open_guide(path):
    with open(path, 'rb') as stream:
        gzipped = stream.read(2) == b'\x1f\x8b'
    return LimitedReader(gzip.open(path, 'rb') if gzipped else open(path, 'rb'))


def guide_channels(path):
    channels = {}
    programme_count = 0
    with open_guide(path) as stream:
        root = None
        for event, item in ET.iterparse(stream, events=('start', 'end')):
            if root is None:
                root = item
                if item.tag != 'tv':
                    raise ValueError('Guide root must be XMLTV tv')
            if event == 'end' and item.tag == 'channel':
                channels[item.get('id', '')] = {'name': item.findtext('display-name', ''), 'names': [x.text or '' for x in item.findall('display-name')]}
                item.clear(); root.clear()
            elif event == 'end' and item.tag == 'programme':
                programme_count += 1
                item.clear(); root.clear()
    if not channels or not programme_count:
        raise ValueError('Guide must contain channels and programmes')
    return channels


def programmes(path):
    with open_guide(path) as stream:
        root = None
        for event, item in ET.iterparse(stream, events=('start', 'end')):
            if root is None:
                root = item
            if event == 'end' and item.tag == 'programme':
                yield item
                item.clear(); root.clear()
            elif event == 'end' and item.tag == 'channel':
                item.clear(); root.clear()


def _has_team(text, game, side):
    names = {normalize(game.get(side + '_short', '')), normalize(game.get(side, ''))}
    if '76ers' in game.get(side, ''):
        names.add('sixers')
    return any(n and re.search(r'(?<![a-z0-9])' + re.escape(n) + r'(?![a-z0-9])', text) for n in names)


def _event_game(entry, catalog, now):
    text = normalize(entry['name'])
    if not re.search(r'\b(?:nfl|nba)\b', text):
        return None
    for game in catalog['games']:
        if not game.get('start_utc'):
            continue
        start = datetime.fromisoformat(game['start_utc'].replace('Z', '+00:00'))
        if now - timedelta(hours=6) <= start <= now + timedelta(hours=36) and _has_team(text, game, 'away') and _has_team(text, game, 'home'):
            return game
    return None


def _guide_for(entry, guide_index):
    original_id = entry['original_id']
    for provider in TRUSTED_GUIDES:
        if original_id and original_id in guide_index.get(provider, {}):
            return provider, original_id
    # First display name only: alternate names often collapse foreign ESPN feeds
    # into a generic ESPN name. Avoid that ambiguity.
    target = canonical(entry['name'])
    expected_region = region(original_id, entry['name'])
    for provider in TRUSTED_GUIDES:
        candidates = [cid for cid, info in guide_index.get(provider, {}).items() if canonical(info['name']) == target and not (expected_region and region(cid, info['name']) and region(cid, info['name']) != expected_region)]
        if len(candidates) == 1:
            return provider, candidates[0]
    return '', ''


def _m3u(entries):
    lines = ['#EXTM3U']
    for entry in entries:
        attrs = dict(entry['attrs'])
        attrs.update({'tvg-id': entry['id'], 'tvg-name': clean_name(entry['name']), 'group-title': ';'.join(entry['groups'])})
        rendered = ' '.join('{}="{}"'.format(k, str(v).replace('"', '&quot;')) for k, v in attrs.items())
        lines.append('#EXTINF:-1 ' + rendered + ',' + clean_name(entry['name']) + ' [' + entry['provider'].title() + ']')
        lines.extend(entry['options'])
        lines.append(entry['url'])
    return '\n'.join(lines) + '\n'


def _publish(staging, destination, filenames):
    backup = pathlib.Path(staging) / 'previous'
    backup.mkdir()
    previous = set()
    published = []
    for name in filenames:
        if (destination / name).exists():
            shutil.copyfile(destination / name, backup / name)
            previous.add(name)
    try:
        for name in filenames:
            os.replace(str(pathlib.Path(staging) / name), str(destination / name))
            published.append(name)
    except Exception:
        for name in reversed(published):
            if name in previous:
                os.replace(str(backup / name), str(destination / name))
            else:
                (destination / name).unlink()
        raise


def build_lists(catalog, playlists, guides, output_dir, now, source_hashes=None):
    now = datetime.fromisoformat(now.replace('Z', '+00:00')) if isinstance(now, str) else now
    if now.tzinfo is None:
        raise ValueError('Build time must include its timezone')
    entries_by_provider = {name: parse_m3u(path) for name, path in playlists.items()}
    if 'doms' not in entries_by_provider or 'doms' not in guides:
        raise ValueError('Doms playlist and guide are required for both switcher choices')
    guide_index = {provider: guide_channels(path) for provider, path in guides.items() if provider in TRUSTED_GUIDES}
    selected = []
    covered = set()
    seen = set()
    for provider, entries in entries_by_provider.items():
        selectors = catalog['selectors'].get(provider, {})
        ids = set(selectors.get('ids', []))
        names = {normalize(x) for x in selectors.get('names', [])}
        for original in entries:
            event_game = _event_game(original, catalog, now)
            if original['original_id'] not in ids and normalize(original['name']) not in names and not event_game:
                continue
            identity = provider + '\0' + original['original_id'] + '\0' + original['name'] + '\0' + original['url']
            uid = 'jvbuilt.sports.' + hashlib.sha256(identity.encode('utf-8')).hexdigest()[:24]
            if uid in seen:
                continue
            seen.add(uid)
            entry = dict(original, provider=provider, id=uid, groups=[], guide_provider='', guide_id='', event_candidate=bool(event_game))
            for game in catalog['games']:
                candidate_names = game.get('candidate_names', {}).get(provider, [])
                if original['name'] in candidate_names or (original['original_id'] and original['original_id'] in game.get('epg_ids', [])) or game is event_game:
                    covered.add(game['id'])
                    group = 'Sports - ' + game['league']
                    if group not in entry['groups']:
                        entry['groups'].append(group)
            if not entry['groups']:
                entry['groups'] = ['Sports - Networks']
            entry['guide_provider'], entry['guide_id'] = _guide_for(entry, guide_index)
            selected.append(entry)
    if not selected:
        raise ValueError('No selected sports channels were found in the current source lists')
    destination = pathlib.Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    public_channels = [{k: e[k] for k in ('id', 'name', 'provider', 'original_id', 'groups', 'guide_provider', 'guide_id', 'event_candidate')} for e in selected]
    if source_hashes is None:
        source_hashes = {kind + '_' + provider: hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest() for kind, sources in (('playlist', playlists), ('guide', guides)) for provider, path in sources.items() if kind == 'playlist' or provider in TRUSTED_GUIDES}
    result = {'generated_utc': now.astimezone(timezone.utc).isoformat(), 'catalog_as_of': catalog.get('as_of', ''), 'source_sha256': source_hashes, 'channels': public_channels, 'unresolved_games': sorted(g['id'] for g in catalog['games'] if g['id'] not in covered), 'covered_games': sorted(covered), 'programmes': 0, 'guide_policy': 'Doms, Loop and EPGTalk only; Mad Titan guide excluded'}
    with tempfile.TemporaryDirectory(prefix='.build-', dir=str(destination)) as temp:
        staging = pathlib.Path(temp)
        (staging / 'sports.m3u').write_text(_m3u(selected), encoding='utf-8')
        with open(staging / 'sports.xml', 'wb') as stream:
            stream.write(b'<?xml version="1.0" encoding="utf-8"?>\n<tv generator-info-name="JVBuilt Sports Setup">\n')
            for entry in selected:
                item = ET.Element('channel', {'id': entry['id']})
                ET.SubElement(item, 'display-name').text = clean_name(entry['name']) + ' [' + entry['provider'].title() + ']'
                if entry['attrs'].get('tvg-logo'):
                    ET.SubElement(item, 'icon', {'src': entry['attrs']['tvg-logo']})
                stream.write(ET.tostring(item, encoding='utf-8') + b'\n')
            for provider in TRUSTED_GUIDES:
                mapping = {}
                for entry in selected:
                    if entry['guide_provider'] == provider:
                        mapping.setdefault(entry['guide_id'], []).append(entry['id'])
                if not mapping:
                    continue
                for item in programmes(guides[provider]):
                    original_id = item.get('channel', '')
                    for target in mapping.get(original_id, []):
                        item.set('channel', target)
                        stream.write(ET.tostring(item, encoding='utf-8') + b'\n')
                        result['programmes'] += 1
                    item.set('channel', original_id)
            stream.write(b'</tv>\n')
        if not result['programmes']:
            raise ValueError('Selected sports channels have no programme listings; previous guide retained')
        shutil.copyfile(playlists['doms'], staging / 'doms.m3u')
        with open_guide(guides['doms']) as source, open(staging / 'doms.xml', 'wb') as target:
            shutil.copyfileobj(source, target)
        (staging / 'coverage.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        _publish(staging, destination, ('sports.m3u', 'sports.xml', 'doms.m3u', 'doms.xml', 'coverage.json'))
    return result
