# JVBuilt and Sports 1.1.0

Choose between **JVBuilt PVR** and **NFL & NBA Sports** in one Kodi program add-on. The separate full Doms playlist option has been removed. This updates the earlier Sports & Doms add-on using the same add-on ID.

## The two lists

- **JVBuilt PVR:** the exact 76-channel personal playlist recovered from Jake's November 12, 2026 backup. Its original channel IDs, stream addresses and playback options are preserved. It uses the saved list's upstream Doms XMLTV guide. The personal playlist is fixed to that backup and is not overwritten by Sports refreshes. It is not proof of the exact list immediately before the November 16 preset changes.
- **NFL & NBA Sports:** 111 channel entries, 86 with EPG, and 7,838 programme listings in the bundled November 16 snapshot. Channel candidates cover 718 of 720 report-eligible games. Two guide-only NBA games have no matching stream; see Coverage.md. These associations do not guarantee game carriage, playback or regional availability.

## Installation and selection

1. Ensure **PVR IPTV Simple Client** is installed in Kodi 21 Omega.
2. Choose **Add-ons → Install from zip file** and select `plugin.program.jvbuilt.sportssetup-1.1.0.zip`. Kodi also requires `script.module.requests`, normally obtained from the Kodi repository. The display name is **JVBuilt and Sports**.
3. Open the add-on under Program add-ons and choose **Enable JVBuilt PVR** or **Enable NFL & NBA Sports**.
4. **Kodi closes automatically after a successful selection. Reopen Kodi to load the selected channels and guide.** A short notification appears before closing. A cancelled menu or failed selection does not close Kodi. Setup saves and verifies the IPTV settings and releases its operation lock before requesting Kodi's Quit command.

Other options refresh Sports, open the TV guide, show status, or restore previous IPTV settings. Restore verifies the original backup and refuses to overwrite settings changed elsewhere. Existing IPTV instances are backed up and disabled while either preset is active; original instance files and filters can be restored byte for byte. No TV/EPG database is deleted, and no recording or playback is started by setup. Reopen Kodi after restoring if its guide still shows old data.

## Guides and refresh

Sports refreshes source playlists and EPG every six hours while its preset is active and its settings remain unchanged. IPTV Simple checks lists hourly. A failed or cancelled source update retains the last complete Sports list. The bundled Sports snapshot was generated at `2026-11-16T18:56:39.470933+00:00`; selecting Sports more than 24 hours later requires a successful refresh.

Sports uses selected channels from Doms, The Loop and Mad Titan. Its merged EPG uses Doms, Loop and EPGTalk; the inconsistent Mad Titan guide is excluded. Removing the standalone Doms choice does not remove the guide sources needed by the two remaining lists. JVBuilt PVR uses a local saved playlist and a remote upstream guide.

The schedule catalog remains fixed to the November 16 report. Refresh changes source playlists and guides, not league schedules, unpublished NBA Cup fixtures or unknown NFL flex/playoff assignments. Some plugin streams require their original Kodi video add-ons, which are not bundled. Stream addresses and guide availability can change; subscriptions, blackouts and regional carriage still apply.

## Checks and limits

The ZIP, manifest, menu, playlist bytes, guide IDs, settings paths, backup/restore, failure recovery and automatic-close requests are checked offline with a simulated Kodi API. **This version has not been installed or run inside Kodi or on Jake's Fire TV. Actual exit, PVR reload and playback behavior remain untested.** No existing Kodi, master or device files were modified; this delivery is ZIP-only.

The standalone jvbuilt.m3u is identical to the recovered backup and the bundled JVBuilt PVR preset. sports.m3u and sports.xml.gz match the bundled Sports snapshot. Playlist files contain stream addresses and should be treated as private configuration. Code is MIT licensed; third-party guides, playlists and streams retain their providers' terms.
