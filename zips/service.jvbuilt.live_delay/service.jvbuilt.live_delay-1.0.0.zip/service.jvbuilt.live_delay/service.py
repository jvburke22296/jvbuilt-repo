import json, time, os, hashlib
from urllib.parse import urlsplit, urljoin, parse_qsl
import xbmc, xbmcgui, xbmcaddon, xbmcvfs, requests

TARGET = 45
def rpc(method, params=None):
    data={'jsonrpc':'2.0','id':1,'method':method}
    if params is not None:data['params']=params
    answer=json.loads(xbmc.executeJSONRPC(json.dumps(data)))
    if 'error' in answer:raise RuntimeError(answer['error']['message'])
    return answer.get('result')

def seconds(t):
    return t.get('hours',0)*3600+t.get('minutes',0)*60+t.get('seconds',0)+t.get('milliseconds',0)/1000.

def live_manifest(raw):
    url,_,encoded=raw.partition('|')
    if urlsplit(url).scheme not in ('http','https'):return False
    if not any(x in urlsplit(url).path.lower() for x in ('.m3u8','.mpd')):return False
    headers=dict(parse_qsl(encoded))
    for depth in range(3):
        with requests.get(url,headers=headers,timeout=(3,4),stream=True) as response:
            response.raise_for_status()
            body=next(response.iter_content(131072),b'').decode('utf-8',errors='replace')
            if '<MPD' in body:return 'type="dynamic"' in body or "type='dynamic'" in body
            if not body.lstrip().startswith('#EXTM3U'):return False
            if '#EXT-X-STREAM-INF' not in body:
                return '#EXTINF:' in body and '#EXT-X-ENDLIST' not in body
            lines=[line.strip() for line in body.splitlines()]
            child=next((line for line in lines if line and not line.startswith('#')),None)
            if not child:return False
            url=urljoin(response.url,child)
    return False

class Events(xbmc.Player):
    def __init__(self):super().__init__();self.generation=0;self.pending=False
    def onAVStarted(self):self.generation+=1;self.pending=True
    def onPlayBackStopped(self):self.generation+=1;self.pending=False
    def onPlayBackEnded(self):self.generation+=1;self.pending=False
    def onPlayBackError(self):self.generation+=1;self.pending=False

def main():
    window=xbmcgui.Window(10000)
    if window.getProperty('JVBuilt.LiveDelay.Running'):return
    window.setProperty('JVBuilt.LiveDelay.Running','true')
    monitor=xbmc.Monitor();events=Events()
    profile=xbmcvfs.translatePath(xbmcaddon.Addon('service.jvbuilt.live_delay').getAddonInfo('profile'))
    os.makedirs(profile,exist_ok=True)
    def record(state,**values):
        values.update({'state':state,'target_seconds':TARGET,'at':time.time()})
        with open(os.path.join(profile,'last-adjustment.json'),'w') as f:json.dump(values,f,indent=2)
        xbmc.log('JVBuilt Live Delay: '+state,xbmc.LOGINFO)
    try:
        while not monitor.waitForAbort(.25):
            if not events.pending:continue
            events.pending=False;generation=events.generation
            if monitor.waitForAbort(1):break
            try:
                players=rpc('Player.GetActivePlayers')
                active=next((p for p in players if p['type']=='video'),None)
                if not active:continue
                pid=active['playerid']
                item=rpc('Player.GetItem',{'playerid':pid,'properties':['file']})['item']
                raw=item.get('file','');pvr=raw.startswith('pvr://channels/tv/') or xbmc.getCondVisibility('PVR.IsPlayingTV')
                props=rpc('Player.GetProperties',{'playerid':pid,'properties':['time','totaltime','speed']})
                if props['speed']!=1 or generation!=events.generation:continue
                if pvr:
                    # IPTV Simple's local timeshift starts at live; pausing builds the delay.
                    rpc('Player.PlayPause',{'playerid':pid,'play':False})
                    record('building_pvr_timeshift',seconds_to_wait=TARGET)
                    deadline=time.monotonic()+TARGET;cancelled=False
                    while time.monotonic()<deadline:
                        if monitor.waitForAbort(.25) or generation!=events.generation:
                            cancelled=True;break
                        speed=rpc('Player.GetProperties',{'playerid':pid,'properties':['speed']})['speed']
                        if speed!=0:cancelled=True;break
                    if cancelled:record('startup_delay_cancelled');continue
                    rpc('Player.PlayPause',{'playerid':pid,'play':True})
                    record('pvr_timeshift_resumed',pause_seconds=TARGET)
                elif live_manifest(raw):
                    if generation!=events.generation:continue
                    props=rpc('Player.GetProperties',{'playerid':pid,'properties':['time','totaltime','speed']})
                    end=seconds(props['totaltime']);position=seconds(props['time'])
                    behind=max(0,end-position)
                    if end<TARGET:
                        record('source_window_too_short',window_seconds=end);continue
                    if props['speed']!=1:continue
                    if behind<TARGET-3:
                        target=max(0,end-TARGET)
                        value={'hours':int(target//3600),'minutes':int(target%3600//60),'seconds':int(target%60),'milliseconds':0}
                        rpc('Player.Seek',{'playerid':pid,'value':value})
                        record('live_window_seek_applied',window_seconds=end,requested_position=target,previous_seconds_behind=behind)
                    else:record('live_delay_already_satisfied',seconds_behind=behind,window_seconds=end)
            except Exception as error:
                record('unsupported_or_unavailable',error_type=type(error).__name__)
    finally:window.clearProperty('JVBuilt.LiveDelay.Running')

if __name__=='__main__':main()
