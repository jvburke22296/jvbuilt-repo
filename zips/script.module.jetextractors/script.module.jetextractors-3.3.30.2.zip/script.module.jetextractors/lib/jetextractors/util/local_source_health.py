"""Short-lived local playback failure observations; no URL credentials are stored."""
import os, json, hashlib, time
import xbmcvfs
_state = {}; _loaded = 0
def is_known_failed(url):
    global _state, _loaded
    now = time.time()
    if now - _loaded > 2:
        try:
            path = os.path.join(xbmcvfs.translatePath('special://profile/addon_data/plugin.video.madtitansports/'), 'source_health.json')
            with open(path, encoding='utf-8') as f: _state = json.load(f)
        except (OSError, ValueError): _state = {}
        _loaded = now
    if not _state.get('enabled', False): return False
    value = str(url).split('|')[0]
    if value.startswith('plugin://plugin.video.madtitansports/sportjetextractors/play?urls=links://'):
        value = value.split('urls=links://', 1)[1]
    key = hashlib.sha256(value.encode('utf-8')).hexdigest()
    return _state.get('failed', {}).get(key, 0) > now
def prefers_adaptive(url):
    is_known_failed(url)  # Refresh shared observations when needed.
    key = hashlib.sha256(str(url).split('|')[0].encode('utf-8')).hexdigest()
    return key in _state.get('adaptive_sources', [])
